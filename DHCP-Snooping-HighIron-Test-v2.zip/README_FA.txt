PNETLab test lab: DHCP-Snooping-HighIron-Test-v2

Import this ZIP as a NEW lab. Do not overwrite the saved static baseline.
The lab uses the authorized image viosl2-adventerprisek9-m.ssa.high_iron_20200929.
The router DHCP pool excludes .1-.10; clients request DHCP. DHCP Option 82 is disabled for this isolated compatibility test.

The .unl embeds startup configs. Separate copies are in configs/ in case you need to inspect/import them manually:
- LAB-SW-TEST.cfg
- LAB-R1.cfg
- Pc1.cfg and pc2.cfg

After import, start all nodes and verify in the consoles:
Router: show ip interface brief; show ip dhcp pool
Switch: show interfaces trunk; show ip dhcp snooping; show ip arp inspection interfaces
Clients: ip dhcp
Then on switch: show ip dhcp snooping binding; show ip dhcp snooping statistics
Expected DHCP leases are in 10.4.86.11-10.4.86.62 (normally the first two are .11 and .12).
After successful leases, check client-to-client and client-to-gateway pings. Save configs only in this test lab once you are satisfied.

This package is structurally validated (ZIP/XML/config payloads); it has NOT been booted in your PNETLab VM from this agent session. The separate CFG files make it possible to inspect or apply configs if your PNETLab import does not apply embedded startup configs automatically.
