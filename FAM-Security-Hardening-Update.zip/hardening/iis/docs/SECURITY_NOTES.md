# یادداشت‌های امنیتی FAM — تصمیمات طراحی و بهبودهای آینده

> این سند تصمیمات آگاهانهٔ امنیتی را مستند می‌کند تا در آینده باز‌بینی‌شونده باشند.
> تاریخ: 2026-10-13

---

## ۱. Rate Limiting — رفتار فعلی در پشت IIS/ARR

### رفتار فعلی

```python
bucket = hashlib.sha256((name + '|' + (request.remote_addr or '')).encode()).hexdigest()
```

چون Flask پشت IIS ARR روی `127.0.0.1:8765` گوش می‌دهد، مقدار `request.remote_addr`
همیشه `127.0.0.1` است. بنابراین rate limiting عملاً **per-username در سطح global** عمل می‌کند:

```
bucket_effective = sha256(username + '|127.0.0.1')
```

### اثر

- یک کاربر داخلی می‌تواند با ۱۰ تلاش ناموفق، ورود همان username را برای ۱۵ دقیقه
  برای همهٔ کاربران محدود کند.
- حساب‌های admin باید نام کاربری متمایز داشته باشند تا هدف این حمله نباشند.
- برای یک اینترانت داخلی با کاربران شناخته‌شده، این سطح ریسک **قابل قبول** است.

### چرا الان X-Forwarded-For نمی‌خوانیم

1. اگر ARR هدر را overwrite نکند، کلاینت می‌تواند مقدار دلخواه بفرستد → IP جعل‌پذیر است.
2. یک `X-Forwarded-For` اشتباه‌تنظیم‌شده بدتر از محدودسازی global فعلی است.
3. تست واقعی روی IIS/ARR موجود انجام نشده است.

### روش صحیح اضافه کردن IP-aware rate limiting (بهبود آینده)

وقتی آماده شد، این مسیر باید طی شود:

1. در IIS ARR، `X-Forwarded-For` را **قبل از proxy** پاک کنید:
   ```xml
   <!-- در web.config، داخل rewrite rules -->
   <rule name="Clear X-Forwarded-For before proxy" stopProcessing="false">
     <match url=".*" />
     <serverVariables>
       <set name="HTTP_X_FORWARDED_FOR" value="{REMOTE_ADDR}" replace="true" />
     </serverVariables>
   </rule>
   ```
2. یک گزینهٔ اختیاری `TRUSTED_PROXY` در `settings.json` اضافه شود:
   ```json
   { "TRUSTED_PROXY": true }
   ```
3. Flask فقط وقتی `TRUSTED_PROXY=true` باشد، هدر را می‌پذیرد:
   ```python
   if app.config.get('TRUSTED_PROXY'):
       real_ip = request.headers.get('X-Forwarded-For', '127.0.0.1').split(',')[0].strip()
   else:
       real_ip = request.remote_addr or ''
   ```
4. یک تست اجرایی با IIS واقعی تأیید کند که IP ثبت‌شده IP کاربر است.
5. تنها بعد از تأیید این ۴ مرحله، `TRUSTED_PROXY` در `settings.json` تولید فعال شود.

---

## ۲. PBKDF2 Iteration Count — بهبود آینده با migration کنترل‌شده

### وضعیت فعلی

```python
hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 210000)
```

`210000` iteration در سال ۲۰۲۳ توصیهٔ OWASP بود. نسخه‌های جدیدتر OWASP
(2024+) برای `PBKDF2-HMAC-SHA256` حدود **600,000** iteration پیشنهاد می‌کنند.

### چرا الان تغییر نمی‌دهیم

- ۲۱۰,۰۰۰ برای این محیط **کافی و ایمن** است.
- تغییر بدون migration، hash‌های قدیمی را بی‌اعتبار نمی‌کند — فقط رمزهای جدید
  با iteration جدید ذخیره می‌شوند.
- بدون version field در جدول `users`، برنامه نمی‌داند hash کاربر با چه iteration
  ساخته شده است.

### مسیر migration کنترل‌شده (بهبود آینده)

این pattern **on-login migration** توصیه می‌شود:

```python
# ۱. ستون جدید به جدول users اضافه شود (additive migration):
# ALTER TABLE users ADD COLUMN kdf_iter INTEGER NOT NULL DEFAULT 210000;

# ۲. در هنگام ورود موفق، اگر iteration قدیمی است:
def login():
    ...  # verify with old hash
    if row['kdf_iter'] < TARGET_ITER:  # TARGET_ITER = 600000
        new_salt, new_hash = credentials(password, iterations=TARGET_ITER)
        db.execute('UPDATE users SET salt=?, hash=?, kdf_iter=? WHERE id=?',
            (new_salt, new_hash, TARGET_ITER, row['id']))
    ...
```

**پیش‌نیازها قبل از پیاده‌سازی:**
- اضافه کردن `kdf_iter` به schema
- تست فشار CPU روی سرور هدف (Windows Server 2019)
- تعیین `TARGET_ITER` بر اساس benchmark سرور واقعی

---

## ۳. تصمیمات امنیتی که عمداً تغییر نکردند

| تصمیم | دلیل |
|---|---|
| `includeSubDomains` در HSTS اضافه نشد | محیط اینترانت — زیردامنه‌ها ممکن است HTTP باشند |
| `preload` در HSTS اضافه نشد | برای intranet hostname عمومی نیست |
| `X-Forwarded-For` بدون ARR config تنظیم نشد | جعل‌پذیر است بدون IIS-side cleanup |
| PBKDF2 iteration بدون migration تغییر نکرد | backward compatibility و فشار CPU |
| firewall rule به صورت پیش‌فرض اضافه نمی‌شود | سیاست شبکه باید توسط مدیر شبکه تنظیم شود |
