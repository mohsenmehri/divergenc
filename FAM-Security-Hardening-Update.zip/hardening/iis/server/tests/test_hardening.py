"""Regression tests for FAM-Security-Hardening-Update.

Covers all 6 hardening items plus the rate-limit documentation check.
Run with: python -m unittest server.tests.test_hardening
"""
import json
import sqlite3
import tempfile
import unittest
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path

from server.app import (
    EPHEMERAL, META, SYSTEM, Problem,
    create_app, validate_state, public_user,
)

ORIGIN = 'http://localhost'
ROOT = Path(__file__).resolve().parents[2]  # server/
WINDOWS = ROOT / 'server' / 'windows'
WWW = ROOT / 'server' / 'www'


class HSTSTest(unittest.TestCase):
    """Hardening item 1 — HSTS max-age must be 1 year (31536000)."""

    def test_hsts_is_one_year(self):
        web_config = WWW / 'web.config'
        tree = ET.parse(web_config)
        ns = ''
        headers = tree.findall('.//{http://}customHeaders/add') or tree.findall('.//customHeaders/add')
        hsts = next(
            (h for h in headers if h.get('name') == 'Strict-Transport-Security'), None
        )
        self.assertIsNotNone(hsts, 'Strict-Transport-Security header not found in web.config')
        value = hsts.get('value', '')
        self.assertIn('max-age=31536000', value,
            f'HSTS max-age must be 31536000 (1 year), got: {value!r}')
        self.assertNotIn('86400', value,
            'Old 1-day max-age=86400 must not appear in HSTS value')

    def test_hsts_has_no_includesubdomains_or_preload(self):
        """Internal intranet: no includeSubDomains or preload directives."""
        web_config = WWW / 'web.config'
        text = web_config.read_text(encoding='utf-8')
        # These directives are intentionally omitted for the internal environment.
        idx = text.find('Strict-Transport-Security')
        line = text[idx:idx+200].split('\n')[0] if idx >= 0 else ''
        self.assertNotIn('preload', line)
        self.assertNotIn('includeSubDomains', line)


class PublicUserSafeParsingTest(unittest.TestCase):
    """Hardening item 2 — public_user() must raise Problem(500) on malformed JSON."""

    def _make_row(self, regions='["1"]', sheets='[]', categories=None, permissions=None):
        """Build a minimal sqlite3.Row-like mapping for public_user()."""
        import sqlite3
        conn = sqlite3.connect(':memory:')
        conn.row_factory = sqlite3.Row
        conn.execute(
            'CREATE TABLE u(id,username,name,role,enabled,revision,salt,hash,regions,sheets,categories,permissions)'
        )
        conn.execute('INSERT INTO u VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
            (str(uuid.uuid4()), 'user1', 'User', 1, 1, str(uuid.uuid4()),
             'aa', 'bb', regions, sheets, categories, permissions))
        conn.commit()
        return conn.execute('SELECT * FROM u').fetchone()

    def test_valid_row_returns_dict(self):
        row = self._make_row()
        result = public_user(row)
        self.assertIsInstance(result, dict)
        self.assertIn('regions', result)
        self.assertIn('sheets', result)
        self.assertNotIn('salt', result)
        self.assertNotIn('hash', result)

    def test_malformed_regions_json_raises_problem_500(self):
        row = self._make_row(regions='NOT_JSON')
        with self.assertRaises(Problem) as ctx:
            public_user(row)
        self.assertEqual(ctx.exception.status, 500)

    def test_regions_not_a_list_raises_problem_500(self):
        row = self._make_row(regions='{"bad": true}')
        with self.assertRaises(Problem) as ctx:
            public_user(row)
        self.assertEqual(ctx.exception.status, 500)

    def test_malformed_sheets_json_raises_problem_500(self):
        row = self._make_row(sheets='{{broken')
        with self.assertRaises(Problem) as ctx:
            public_user(row)
        self.assertEqual(ctx.exception.status, 500)

    def test_malformed_categories_raises_problem_500(self):
        row = self._make_row(categories='NOT_JSON', permissions='[]')
        with self.assertRaises(Problem) as ctx:
            public_user(row)
        self.assertEqual(ctx.exception.status, 500)

    def test_malformed_permissions_raises_problem_500(self):
        row = self._make_row(categories='[]', permissions='NOT_JSON')
        with self.assertRaises(Problem) as ctx:
            public_user(row)
        self.assertEqual(ctx.exception.status, 500)

    def test_categories_not_a_list_raises_problem_500(self):
        row = self._make_row(categories='"a string"', permissions='[]')
        with self.assertRaises(Problem) as ctx:
            public_user(row)
        self.assertEqual(ctx.exception.status, 500)

    def test_problem_message_does_not_contain_raw_db_value(self):
        """Error message must not leak internal DB content to caller."""
        secret = 'SECRET_INTERNAL_DB_VALUE_12345'
        row = self._make_row(regions=f'[INVALID {secret}]')
        with self.assertRaises(Problem) as ctx:
            public_user(row)
        self.assertNotIn(secret, ctx.exception.message)


class ValidateStateSystemSheetTest(unittest.TestCase):
    """Hardening item 3 — validate_state must reject SYSTEM-but-not-META sheet names."""

    def _minimal_state(self, **overrides):
        base = {
            'v': 2, 'order': [], 'sheets': {},
            'lockedSheets': {}, 'categoryConfig': None,
            'regionConfig': None, 'panelProtected': True,
        }
        base.update(overrides)
        return base

    def test_ephemeral_system_name_in_order_raises_400(self):
        for bad in list(EPHEMERAL)[:3]:  # test a sample
            with self.subTest(name=bad):
                state = self._minimal_state(
                    order=[bad],
                    sheets={bad: {'rows': [['A']], 'merges': []}}
                )
                with self.assertRaises(Problem) as ctx:
                    validate_state(state)
                self.assertEqual(ctx.exception.status, 400,
                    f'EPHEMERAL sheet {bad!r} should be rejected with 400')

    def test_meta_system_names_are_allowed_through_validate_state(self):
        """META sheets (SYSTEM_SHEET_CONFIG, SYSTEM_KEYS) may appear in browser state."""
        for ok in META:
            with self.subTest(name=ok):
                state = self._minimal_state(
                    order=[ok],
                    sheets={ok: {'rows': [['A']], 'merges': []}}
                )
                # Should NOT raise — META names are legitimate in browser payloads.
                try:
                    validate_state(state)
                except Problem as e:
                    if e.status == 400 and 'سیستمی' in e.message:
                        self.fail(f'META sheet {ok!r} was incorrectly rejected')

    def test_normal_sheet_name_is_accepted(self):
        state = self._minimal_state(
            order=['تهران'],
            sheets={'تهران': {'rows': [['A', 'B'], [1, 2]], 'merges': []}}
        )
        result = validate_state(state)  # must not raise
        self.assertIn('تهران', result['order'])

    def test_all_ephemeral_names_are_rejected(self):
        """Every member of EPHEMERAL must trigger the 400 guard."""
        for name in EPHEMERAL:
            with self.subTest(name=name):
                state = self._minimal_state(
                    order=[name],
                    sheets={name: {'rows': [['A']], 'merges': []}}
                )
                with self.assertRaises(Problem) as ctx:
                    validate_state(state)
                self.assertEqual(ctx.exception.status, 400)


class InstallerAllowlistTest(unittest.TestCase):
    """Hardening item 4 — setup-ertebatat.ps1 must use an explicit file allowlist."""

    def _setup_ps1_text(self):
        return (WINDOWS / 'setup-ertebatat.ps1').read_text(encoding='utf-8')

    def test_no_wildcard_py_glob_in_file_copy_block(self):
        text = self._setup_ps1_text()
        # The old wildcard pattern must not appear
        self.assertNotIn("Get-ChildItem $SourceServer -File -Filter '*.py'", text,
            'Wildcard *.py glob must be replaced with an explicit allowlist')

    def test_explicit_server_files_allowlist_present(self):
        text = self._setup_ps1_text()
        for expected in ('app.py', 'manage.py', 'requirements.txt'):
            self.assertIn(f"'{expected}'", text,
                f'{expected!r} must appear in the explicit server-files allowlist')

    def test_explicit_windows_files_allowlist_present(self):
        text = self._setup_ps1_text()
        for expected in ('install.ps1', 'start.ps1', 'backup-daily.ps1',
                         'verify_deployment.py', 'setup-common.psm1'):
            self.assertIn(f"'{expected}'", text,
                f'{expected!r} must appear in the explicit windows-files allowlist')

    def test_explicit_www_files_allowlist_present(self):
        text = self._setup_ps1_text()
        for expected in ('FAM.html', 'web.config'):
            self.assertIn(f"'{expected}'", text,
                f'{expected!r} must appear in the explicit www-files allowlist')

    def test_allowlist_variables_defined(self):
        text = self._setup_ps1_text()
        self.assertIn('$ServerFiles', text)
        self.assertIn('$WindowsFiles', text)
        self.assertIn('$WwwFiles', text)


class PythonVersionFallbackTest(unittest.TestCase):
    """Hardening item 5 — install.ps1 fallback order must be 3.14 → 3.13 → 3.12."""

    def _install_ps1_text(self):
        return (WINDOWS / 'install.ps1').read_text(encoding='utf-8')

    def test_no_single_version_hardcoded_py_call(self):
        text = self._install_ps1_text()
        self.assertNotIn("& py -3.12 -c", text,
            'Single hardcoded py -3.12 call must be replaced with a version loop')

    def test_version_loop_covers_three_versions(self):
        text = self._install_ps1_text()
        for ver in ('3.14', '3.13', '3.12'):
            self.assertIn(ver, text, f'Python {ver} must appear in the fallback loop')

    def test_priority_order_3_14_before_3_12(self):
        text = self._install_ps1_text()
        idx_314 = text.find('3.14')
        idx_312 = text.find('3.12')
        self.assertGreater(idx_314, 0, '3.14 must appear in install.ps1')
        self.assertGreater(idx_312, 0, '3.12 must appear in install.ps1')
        self.assertLess(idx_314, idx_312,
            '3.14 must appear before 3.12 (priority order: 3.14 → 3.13 → 3.12)')

    def test_setup_ertebatat_and_install_share_same_priority_order(self):
        setup_text = (WINDOWS / 'setup-ertebatat.ps1').read_text(encoding='utf-8')
        install_text = self._install_ps1_text()
        for ver in ('3.14', '3.13', '3.12'):
            self.assertIn(ver, setup_text, f'{ver} must be in setup-ertebatat.ps1')
            self.assertIn(ver, install_text, f'{ver} must be in install.ps1')
        # Both must prefer 3.14 over 3.12
        s_314 = setup_text.find('3.14')
        s_312 = setup_text.find('3.12')
        i_314 = install_text.find('3.14')
        i_312 = install_text.find('3.12')
        self.assertLess(s_314, s_312, 'setup-ertebatat.ps1: 3.14 before 3.12')
        self.assertLess(i_314, i_312, 'install.ps1: 3.14 before 3.12')


class RateLimitDocumentationTest(unittest.TestCase):
    """Hardening item 6 (documentation) — rate-limit behaviour behind ARR.

    The rate-limit bucket is (username + remote_addr).  Because Flask receives
    all traffic proxied via IIS ARR on 127.0.0.1, this effectively becomes
    per-username-global in production.  The current model is intentional and
    SAFE on an intranet; no TRUSTED_PROXY change is applied without real ARR
    testing.  These tests verify the *current* semantics are stable.
    """

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        path = str(Path(self.tmp.name) / 'fam.sqlite3')
        cfg = {'DB_PATH': path, 'PUBLIC_ORIGIN': ORIGIN,
               'TESTING': True, 'COOKIE_SECURE': False}
        self.app = create_app(cfg)

    def tearDown(self):
        self.tmp.cleanup()

    def _post_login(self, client, username='absent', password='xxxx'):
        return client.post('/api/login',
            json={'username': username, 'password': password},
            headers={'Origin': ORIGIN})

    def test_rate_limit_triggers_after_10_failures_for_same_username(self):
        """10 failed logins → 11th is 429. Bucket is per-username (not per-IP in prod)."""
        c = self.app.test_client()
        for _ in range(10):
            r = self._post_login(c)
            self.assertEqual(r.status_code, 401)
        r = self._post_login(c)
        self.assertEqual(r.status_code, 429,
            'Expected 429 after 10 failed attempts for same username')

    def test_rate_limit_does_not_block_different_username(self):
        """Rate limit is per-bucket: blocking one username must not block another."""
        c = self.app.test_client()
        for _ in range(10):
            self._post_login(c, username='victim')
        # A different username (different bucket) must still get 401, not 429.
        r = self._post_login(c, username='admin')
        self.assertNotEqual(r.status_code, 429,
            'Rate limit for one username must not bleed to another')

    def test_rate_limit_does_not_block_correct_password_from_admin(self):
        """After triggering the limit on a non-existent user,
        the admin account with correct password must still authenticate."""
        c = self.app.test_client()
        for _ in range(11):
            self._post_login(c, username='nobody')
        r = self._post_login(c, username='admin', password='1109')
        self.assertEqual(r.status_code, 200,
            'Admin login must succeed even after rate-limit on another username')

    def test_trusted_proxy_setting_not_present(self):
        """Confirm no TRUSTED_PROXY / X-Forwarded-For trust is active
        without explicit IIS ARR validation (intentional decision)."""
        import server.app as app_module
        source = Path(app_module.__file__).read_text(encoding='utf-8')
        self.assertNotIn('TRUSTED_PROXY', source,
            'TRUSTED_PROXY must not be added without IIS ARR validation')
        self.assertNotIn('X-Forwarded-For', source,
            'X-Forwarded-For trust must not be added without IIS ARR validation')


if __name__ == '__main__':
    unittest.main()
