"""Static regression tests for FAM-Security-Hardening-Update.

This module checks only FILE CONTENT (no Flask/SQLite import needed).
Runs in any Python 3.8+ environment, including the build/CI sandbox.

Full app-level tests that require Flask live in test_hardening.py
and must be run on the actual Windows Server inside the venv.

Run: python -m unittest server.tests.test_hardening_static -v
"""
import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]      # .../iis/
SERVER = ROOT / 'server'
WINDOWS = SERVER / 'windows'
WWW = SERVER / 'www'


class HSTS1YearTest(unittest.TestCase):
    """Hardening 1 — HSTS max-age must be 31536000 (1 year)."""

    def _hsts_value(self):
        text = (WWW / 'web.config').read_text(encoding='utf-8')
        m = re.search(r'Strict-Transport-Security[^>]*value="([^"]+)"', text)
        self.assertIsNotNone(m, 'Strict-Transport-Security not found in web.config')
        return m.group(1)

    def test_max_age_is_one_year(self):
        v = self._hsts_value()
        self.assertIn('max-age=31536000', v,
            f'HSTS max-age must be 31536000, got: {v!r}')

    def test_old_one_day_value_gone(self):
        v = self._hsts_value()
        self.assertNotIn('86400', v,
            f'Old max-age=86400 must be removed, got: {v!r}')

    def test_no_includesubdomains_or_preload(self):
        v = self._hsts_value()
        self.assertNotIn('preload', v.lower())
        self.assertNotIn('includesubdomains', v.lower())


class AppPyPublicUserTest(unittest.TestCase):
    """Hardening 2 — public_user() must have try/except JSON guards."""

    def _app_src(self):
        return (SERVER / 'app.py').read_text(encoding='utf-8')

    def test_load_list_helper_defined(self):
        src = self._app_src()
        self.assertIn('def _load_list', src,
            '_load_list helper must be defined inside public_user()')

    def test_json_decode_error_caught(self):
        src = self._app_src()
        self.assertIn('json.JSONDecodeError', src)

    def test_type_check_on_json_result(self):
        src = self._app_src()
        self.assertIn('isinstance(v,list)', src,
            'Type check must confirm JSON result is a list')

    def test_fail_500_on_malformed(self):
        src = self._app_src()
        self.assertIn('fail(500', src,
            'fail(500,...) must be called on malformed JSON')

    def test_raw_json_loads_not_bare_in_public_user(self):
        """json.loads in public_user() must only exist inside the _load_list helper."""
        src = self._app_src()
        start = src.find('def public_user')
        next_def = src.find('\ndef ', start + 10)
        body = src[start:next_def]
        # Remove the _load_list inner-function body from scan scope
        ll_start = body.find('    def _load_list')
        ll_end   = body.find('\n        names.add', ll_start)  # next statement after helper
        if ll_start < 0:
            self.fail('_load_list helper not found inside public_user()')
        body_outside = body[:ll_start] + body[ll_end:]
        bare = re.findall(r'json\.loads\(', body_outside)
        self.assertEqual(bare, [],
            f'json.loads outside _load_list in public_user() must not exist: {bare}')

    def test_secret_not_in_error_message(self):
        """Error message string in fail() must not reference internal column names."""
        src = self._app_src()
        # The string passed to fail(500,...) inside public_user must not contain 'DB' or 'column'
        start = src.find('def public_user')
        next_def = src.find('\ndef ', start + 10)
        body = src[start:next_def]
        fail_msgs = re.findall(r"fail\(500,'([^']+)'", body)
        for msg in fail_msgs:
            for leak in ('db.', 'sqlite', 'column', 'row', 'table'):
                self.assertNotIn(leak, msg.lower(),
                    f'Error message must not leak internal detail: {msg!r}')


class AppPyValidateStateTest(unittest.TestCase):
    """Hardening 3 — validate_state must explicitly reject SYSTEM-not-META names."""

    def _app_src(self):
        return (SERVER / 'app.py').read_text(encoding='utf-8')

    def test_system_not_meta_check_present(self):
        src = self._app_src()
        self.assertIn('name in SYSTEM and name not in META', src,
            'validate_state must include: if name in SYSTEM and name not in META')

    def test_check_raises_400(self):
        src = self._app_src()
        # The check must be followed by fail(400,...)
        idx = src.find('name in SYSTEM and name not in META')
        self.assertGreater(idx, 0)
        snippet = src[idx:idx+120]
        self.assertIn('fail(400', snippet,
            'SYSTEM-not-META guard must call fail(400,...)')

    def test_check_inside_validate_state_function(self):
        src = self._app_src()
        start = src.find('def validate_state')
        self.assertGreater(start, 0, 'validate_state function must exist')
        next_def = src.find('\ndef ', start + 10)
        body = src[start:next_def]
        self.assertIn('name in SYSTEM and name not in META', body,
            'SYSTEM-not-META guard must be inside validate_state')

    def test_meta_not_rejected_separately(self):
        """There must not be a blanket 'if name in SYSTEM' without the META exception."""
        src = self._app_src()
        start = src.find('def validate_state')
        next_def = src.find('\ndef ', start + 10)
        body = src[start:next_def]
        # Any 'name in SYSTEM' must be paired with 'not in META'
        for m in re.finditer(r'name in SYSTEM', body):
            ctx = body[m.start():m.start()+80]
            self.assertIn('not in META', ctx,
                f'Every "name in SYSTEM" must be guarded by "not in META": {ctx!r}')


class InstallerAllowlistTest(unittest.TestCase):
    """Hardening 4 — setup-ertebatat.ps1 must use an explicit file allowlist."""

    def _setup_text(self):
        return (WINDOWS / 'setup-ertebatat.ps1').read_text(encoding='utf-8')

    def test_no_wildcard_py_glob(self):
        text = self._setup_text()
        self.assertNotIn("Get-ChildItem $SourceServer -File -Filter '*.py'", text,
            'Wildcard *.py glob must be replaced with explicit allowlist')

    def test_server_allowlist_variables(self):
        text = self._setup_text()
        self.assertIn('$ServerFiles', text)
        self.assertIn('$WindowsFiles', text)
        self.assertIn('$WwwFiles', text)

    def test_core_server_files_listed(self):
        text = self._setup_text()
        for f in ('app.py', 'manage.py', 'requirements.txt'):
            self.assertIn(f"'{f}'", text, f'{f!r} must be in allowlist')

    def test_core_windows_files_listed(self):
        text = self._setup_text()
        for f in ('install.ps1', 'start.ps1', 'backup-daily.ps1',
                  'verify_deployment.py', 'setup-common.psm1'):
            self.assertIn(f"'{f}'", text, f'{f!r} must be in allowlist')

    def test_www_files_listed(self):
        text = self._setup_text()
        for f in ('FAM.html', 'web.config'):
            self.assertIn(f"'{f}'", text, f'{f!r} must be in allowlist')

    def test_no_extension_wildcard_in_files_assignment(self):
        text = self._setup_text()
        # No .py or .ps1 wildcard patterns in the $Files block
        self.assertNotRegex(text, r"Filter '\*\.py'")
        self.assertNotRegex(text, r"Filter '\*\.ps1'")


class PythonVersionOrderTest(unittest.TestCase):
    """Hardening 5 — Python version fallback must be 3.14 → 3.13 → 3.12 in both files."""

    def _install_text(self):
        return (WINDOWS / 'install.ps1').read_text(encoding='utf-8')

    def _setup_text(self):
        return (WINDOWS / 'setup-ertebatat.ps1').read_text(encoding='utf-8')

    def test_install_no_single_hardcoded_version(self):
        text = self._install_text()
        self.assertNotIn("& py -3.12 -c", text,
            'Single py -3.12 call must be replaced with a loop')

    def test_install_has_all_three_versions(self):
        text = self._install_text()
        for v in ('3.14', '3.13', '3.12'):
            self.assertIn(v, text, f'Python {v} must be in install.ps1')

    def test_install_3_14_appears_before_3_12(self):
        text = self._install_text()
        self.assertLess(text.find('3.14'), text.find('3.12'),
            'install.ps1: 3.14 must appear before 3.12')

    def test_setup_has_all_three_versions(self):
        text = self._setup_text()
        for v in ('3.14', '3.13', '3.12'):
            self.assertIn(v, text, f'Python {v} must be in setup-ertebatat.ps1')

    def test_setup_3_14_appears_before_3_12(self):
        text = self._setup_text()
        self.assertLess(text.find('3.14'), text.find('3.12'),
            'setup-ertebatat.ps1: 3.14 must appear before 3.12')

    def test_both_files_share_same_priority_order(self):
        install = self._install_text()
        setup = self._setup_text()
        for v in ('3.14', '3.13', '3.12'):
            self.assertIn(v, install, f'{v} missing from install.ps1')
            self.assertIn(v, setup, f'{v} missing from setup-ertebatat.ps1')
        # Ensure consistent ordering: 3.14 < 3.13 < 3.12 in both
        for text, name in ((install, 'install.ps1'), (setup, 'setup-ertebatat.ps1')):
            p314, p313, p312 = text.find('3.14'), text.find('3.13'), text.find('3.12')
            self.assertLess(p314, p313, f'{name}: 3.14 must come before 3.13')
            self.assertLess(p313, p312, f'{name}: 3.13 must come before 3.12')


class RateLimitNoTrustedProxyTest(unittest.TestCase):
    """Hardening 6 (doc) — TRUSTED_PROXY must not be added without ARR validation."""

    def test_no_trusted_proxy_in_app(self):
        src = (SERVER / 'app.py').read_text(encoding='utf-8')
        self.assertNotIn('TRUSTED_PROXY', src,
            'TRUSTED_PROXY must not appear in app.py without IIS ARR validation')

    def test_no_xforwardedfor_trust_in_app(self):
        src = (SERVER / 'app.py').read_text(encoding='utf-8')
        self.assertNotIn('X-Forwarded-For', src,
            'X-Forwarded-For trust must not be added without IIS ARR validation')

    def test_security_notes_documents_rate_limit(self):
        notes = (ROOT / 'docs' / 'SECURITY_NOTES.md').read_text(encoding='utf-8')
        self.assertIn('127.0.0.1', notes,
            'SECURITY_NOTES.md must document the loopback rate-limit behaviour')
        self.assertIn('TRUSTED_PROXY', notes,
            'SECURITY_NOTES.md must describe the future TRUSTED_PROXY upgrade path')

    def test_security_notes_documents_pbkdf2_migration(self):
        notes = (ROOT / 'docs' / 'SECURITY_NOTES.md').read_text(encoding='utf-8')
        self.assertIn('600', notes,
            'SECURITY_NOTES.md must reference 600000 iteration target')
        self.assertIn('kdf_iter', notes,
            'SECURITY_NOTES.md must document on-login migration field')


if __name__ == '__main__':
    unittest.main()
