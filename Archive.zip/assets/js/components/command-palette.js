/**
 * پالت فرمان (⌘K / Ctrl+K) — جستجو و پیمایش با کیبورد
 */
(function (Nava) {
  'use strict';
  const { $, $$, escape } = Nava.utils;
  const modal = $('[data-cmdk]');
  if (!modal) return;
  const input = $('[data-cmdk-input]', modal);
  const list = $('[data-cmdk-list]', modal);

  const ITEMS = Nava.layout.pages
    .map((p) => ({ group: 'صفحات', label: p.label, icon: p.icon, href: p.href }))
    .concat([
      { group: 'عملیات', label: 'افزودن محصول جدید', icon: 'plus', href: 'products.html#new' },
      { group: 'عملیات', label: 'مشاهده سفارش‌های در انتظار', icon: 'bag', href: 'orders.html#pending' },
      { group: 'عملیات', label: 'دعوت از همکار', icon: 'user-plus', href: 'settings.html#team' },
      { group: 'عملیات', label: 'خروجی گزارش ماهانه', icon: 'download', href: 'reports.html' },
      { group: 'عملیات', label: 'تغییر تم روشن / تیره', icon: 'moon', action: () => Nava.theme.toggle() },
      { group: 'حساب', label: 'پروفایل من', icon: 'user', href: 'profile.html' },
      { group: 'حساب', label: 'خروج از حساب', icon: 'logout', href: 'login.html' },
    ]);

  let filtered = ITEMS;
  let active = 0;
  let lastFocus = null;

  function render() {
    const q = input.value.trim();
    filtered = ITEMS.filter((i) => i.label.includes(q) || i.group.includes(q));
    active = Math.min(active, Math.max(0, filtered.length - 1));
    if (!filtered.length) {
      list.innerHTML = '<li class="py-10 text-center text-sm text-muted-foreground">نتیجه‌ای یافت نشد.</li>';
      return;
    }
    let html = '';
    let group = '';
    filtered.forEach((item, i) => {
      if (item.group !== group) {
        group = item.group;
        html += '<li class="px-2 pb-1 pt-3 text-[11px] font-semibold text-muted-foreground first:pt-1" role="presentation">' + escape(group) + '</li>';
      }
      const on = i === active;
      html +=
        '<li role="option" aria-selected="' + on + '" data-index="' + i + '" class="flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors ' + (on ? 'bg-primary text-primary-foreground' : 'hover:bg-muted') + '">' +
        Nava.icons.svg(item.icon, 'size-4 ' + (on ? '' : 'text-muted-foreground')) +
        '<span class="flex-1">' + escape(item.label) + '</span>' +
        (on ? Nava.icons.svg('corner-left', 'size-4 opacity-70') : '') +
        '</li>';
    });
    list.innerHTML = html;
    const el = $('[aria-selected="true"]', list);
    el && el.scrollIntoView({ block: 'nearest' });
  }

  function open() {
    lastFocus = document.activeElement;
    modal.classList.remove('hidden');
    input.value = '';
    active = 0;
    render();
    requestAnimationFrame(() => input.focus());
  }
  function close() {
    modal.classList.add('hidden');
    lastFocus && lastFocus.focus();
  }
  function run(i) {
    const item = filtered[i];
    if (!item) return;
    close();
    if (item.action) item.action();
    else location.href = item.href;
  }

  input.addEventListener('input', () => { active = 0; render(); });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); active = (active + 1) % filtered.length; render(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); active = (active - 1 + filtered.length) % filtered.length; render(); }
    else if (e.key === 'Enter') { e.preventDefault(); run(active); }
  });
  list.addEventListener('click', (e) => {
    const li = e.target.closest('[data-index]');
    li && run(+li.dataset.index);
  });
  list.addEventListener('mousemove', (e) => {
    const li = e.target.closest('[data-index]');
    if (li && +li.dataset.index !== active) { active = +li.dataset.index; render(); }
  });

  $$('[data-cmdk-open]').forEach((b) => b.addEventListener('click', open));
  $$('[data-cmdk-close]', modal).forEach((b) => b.addEventListener('click', close));
  document.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); modal.classList.contains('hidden') ? open() : close(); }
    else if (e.key === 'Escape' && !modal.classList.contains('hidden')) close();
  });
})(window.Nava);
