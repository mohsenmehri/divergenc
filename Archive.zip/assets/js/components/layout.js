/**
 * چیدمان مشترک پنل: سایدبار، هدر، پالت فرمان و محل اعلان‌ها
 * هر صفحه فقط <body data-page="..."> و <div class="app-main"> را دارد؛
 * بقیه‌ی پوسته از اینجا ساخته می‌شود تا تکرار کد در صفحات نباشد.
 */
(function (Nava) {
  'use strict';
  const { escape } = Nava.utils;

  /* ---------- پیکربندی منو ---------- */
  const NAV = [
    {
      title: 'اصلی',
      items: [
        { id: 'dashboard', href: 'index.html', label: 'داشبورد', icon: 'dashboard' },
        { id: 'analytics', href: 'analytics.html', label: 'تحلیل‌ها', icon: 'chart' },
        { id: 'orders', href: 'orders.html', label: 'سفارش‌ها', icon: 'bag', badge: '۱۲' },
        { id: 'products', href: 'products.html', label: 'محصولات', icon: 'package' },
        { id: 'customers', href: 'customers.html', label: 'مشتریان', icon: 'users' },
      ],
    },
    {
      title: 'مدیریت',
      items: [
        { id: 'messages', href: 'messages.html', label: 'پیام‌ها', icon: 'message', dot: true },
        { id: 'reports', href: 'reports.html', label: 'گزارش‌ها', icon: 'file' },
        { id: 'settings', href: 'settings.html', label: 'تنظیمات', icon: 'settings' },
        { id: 'profile', href: 'profile.html', label: 'پروفایل', icon: 'user' },
      ],
    },
    {
      title: 'صفحات',
      items: [
        { id: 'login', href: 'login.html', label: 'ورود', icon: 'log-in' },
        { id: 'register', href: 'register.html', label: 'ثبت‌نام', icon: 'user-plus' },
        { id: 'forgot', href: 'forgot-password.html', label: 'بازیابی رمز', icon: 'key' },
        { id: '404', href: '404.html', label: 'صفحه‌ی ۴۰۴', icon: 'alert' },
      ],
    },
  ];
  const ALL_PAGES = NAV.flatMap((g) => g.items);

  const page = document.body.dataset.page;
  const i = (name, cls) => '<i data-icon="' + name + '" class="' + (cls || '') + '"></i>';

  /* ---------- قالب‌ها ---------- */
  const background =
    '<div aria-hidden="true" class="pointer-events-none fixed inset-0 -z-10 overflow-hidden">' +
      '<div class="absolute -top-40 start-1/3 size-[36rem] rounded-full bg-primary/5 blur-3xl animate-aurora dark:bg-primary/5"></div>' +
      '<div class="absolute top-1/3 -end-40 size-[30rem] rounded-full bg-accent/10 blur-3xl animate-aurora [animation-delay:-6s]"></div>' +
      '<div class="absolute inset-0 bg-grid [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]"></div>' +
    '</div>';

  function navItem(item) {
    const current = item.id === page ? ' aria-current="page"' : '';
    let extra = '';
    if (item.badge) extra = '<span class="sidebar-label sidebar-hide badge badge-accent ms-auto">' + item.badge + '</span>';
    if (item.dot) extra = '<span class="sidebar-label sidebar-hide ms-auto size-2 rounded-full bg-accent"></span>';
    return '<li><a href="' + item.href + '" class="nav-link"' + current + ' title="' + escape(item.label) + '">' +
      i(item.icon, 'nav-icon') + '<span class="sidebar-label">' + escape(item.label) + '</span>' + extra + '</a></li>';
  }

  const sidebar =
    '<aside id="sidebar" class="app-sidebar fixed inset-y-0 start-0 z-40 flex flex-col border-e glass" aria-label="منوی اصلی">' +
      '<div class="flex h-16 shrink-0 items-center gap-3 px-5">' +
        '<a href="index.html" class="flex items-center gap-3" aria-label="نوا — داشبورد">' +
          '<img src="assets/img/logo.svg" alt="" class="size-9 shrink-0" width="36" height="36">' +
          '<div class="sidebar-label"><p class="text-base font-extrabold tracking-tight">نوا</p><p class="-mt-0.5 text-[11px] text-muted-foreground">پنل مدیریت فروشگاه</p></div>' +
        '</a>' +
        '<button type="button" class="btn-icon ms-auto lg:hidden" data-sidebar-close aria-label="بستن منو">' + i('x', 'size-5') + '</button>' +
      '</div>' +
      '<nav class="relative flex-1 overflow-y-auto overflow-x-hidden px-3 py-4" data-nav>' +
        '<span class="nav-indicator" data-nav-indicator aria-hidden="true"></span>' +
        NAV.map((g, gi) =>
          '<p class="sidebar-label sidebar-hide mb-2 px-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70' + (gi ? ' mt-6' : '') + '">' + g.title + '</p>' +
          '<ul class="relative space-y-1">' + g.items.map(navItem).join('') + '</ul>'
        ).join('') +
      '</nav>' +
      '<div class="sidebar-hide p-3">' +
        '<div class="relative overflow-hidden rounded-xl border border-white/10 bg-zinc-950 p-4 text-white">' +
          '<div aria-hidden="true" class="absolute -end-8 -top-8 size-28 rounded-full bg-accent/50 blur-2xl"></div>' +
          '<div aria-hidden="true" class="absolute -bottom-10 start-0 size-24 rounded-full bg-warning/20 blur-2xl"></div>' +
          i('sparkles', 'relative size-5 text-accent') +
          '<p class="relative mt-2 text-sm font-bold">نسخه‌ی حرفه‌ای</p>' +
          '<p class="relative mt-1 text-xs leading-5 text-white/70">گزارش‌های پیشرفته و هوش تجاری را فعال کنید.</p>' +
          '<a href="settings.html#billing" class="btn relative mt-3 h-8 w-full bg-white text-xs text-zinc-900 hover:bg-zinc-100">ارتقا حساب</a>' +
        '</div>' +
      '</div>' +
      '<div class="hidden border-t p-3 lg:block">' +
        '<button type="button" class="nav-link w-full" data-collapse-toggle title="جمع کردن منو">' +
          i('panel', 'nav-icon collapse-icon transition-transform duration-500') + '<span class="sidebar-label">جمع کردن منو</span>' +
        '</button>' +
      '</div>' +
    '</aside>' +
    '<div class="fixed inset-0 z-30 bg-black/40 opacity-0 backdrop-blur-sm transition-opacity duration-300 pointer-events-none lg:hidden [.sidebar-open_&]:pointer-events-auto [.sidebar-open_&]:opacity-100" data-sidebar-close aria-hidden="true"></div>';

  const menuLink = (href, icon, label, cls) =>
    '<a href="' + href + '" class="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm ' + (cls || 'hover:bg-muted') + '" role="menuitem">' + i(icon, 'size-4 ' + (cls ? '' : 'text-muted-foreground')) + label + '</a>';

  const header =
    '<header class="sticky top-0 z-20 flex h-16 items-center gap-2 border-b glass px-4 sm:px-6">' +
      '<button type="button" class="btn-icon lg:hidden" data-sidebar-open aria-label="باز کردن منو">' + i('menu', 'size-5') + '</button>' +
      '<button type="button" data-cmdk-open class="group flex h-10 w-full max-w-sm items-center gap-2 rounded-lg border bg-card/60 px-3 text-sm text-muted-foreground transition hover:border-foreground/20 hover:bg-card">' +
        i('search', 'size-4 transition-transform duration-300 group-hover:scale-110') +
        '<span class="truncate">جستجو در پنل…</span>' +
        '<span class="ms-auto hidden items-center gap-1 sm:flex" dir="ltr"><kbd class="kbd">⌘</kbd><kbd class="kbd">K</kbd></span>' +
      '</button>' +
      '<div class="ms-auto flex items-center gap-1">' +
        '<button type="button" class="btn-icon overflow-hidden" data-theme-toggle aria-label="تغییر تم">' +
          i('sun', 'size-5 [grid-area:1/1] transition-all duration-500 dark:-rotate-90 dark:scale-0') +
          i('moon', 'size-5 [grid-area:1/1] rotate-90 scale-0 transition-all duration-500 dark:rotate-0 dark:scale-100') +
        '</button>' +
        '<div class="relative" data-popover>' +
          '<button type="button" class="btn-icon" data-popover-trigger aria-haspopup="true" aria-expanded="false" aria-label="اعلان‌ها">' + i('bell', 'size-5') +
            '<span class="absolute end-2 top-2 flex size-2.5"><span class="absolute inline-flex size-full animate-pulse-ring rounded-full bg-accent"></span><span class="relative inline-flex size-2.5 rounded-full border-2 border-background bg-accent"></span></span>' +
          '</button>' +
          '<div class="popover -end-2 w-[min(22rem,calc(100vw-2rem))] sm:end-0" data-popover-panel data-open="false" role="menu">' +
            '<div class="flex items-center justify-between border-b px-4 py-3"><p class="text-sm font-semibold">اعلان‌ها</p><button type="button" class="text-xs font-medium text-accent hover:underline" data-notif-read>علامت‌گذاری همه</button></div>' +
            '<ul class="max-h-80 divide-y overflow-y-auto" data-notifications></ul>' +
            '<a href="messages.html" class="block border-t px-4 py-2.5 text-center text-xs font-medium text-muted-foreground hover:text-foreground">مشاهده همه پیام‌ها</a>' +
          '</div>' +
        '</div>' +
        '<span class="mx-1 hidden h-6 w-px bg-border sm:block"></span>' +
        '<div class="relative" data-popover>' +
          '<button type="button" class="flex items-center gap-2 rounded-lg p-1 pe-2 transition hover:bg-muted" data-popover-trigger aria-haspopup="true" aria-expanded="false">' +
            '<span class="relative grid size-8 place-items-center rounded-full bg-gradient-to-br from-zinc-700 to-zinc-950 text-sm font-bold text-white ring-2 ring-accent/30">م' +
              '<span class="absolute -bottom-0.5 -end-0.5 size-3 rounded-full border-2 border-background bg-accent"></span></span>' +
            '<span class="hidden text-start leading-tight sm:block"><span class="block text-sm font-semibold">مدیر سیستم</span><span class="block text-[11px] text-muted-foreground">admin@nava.ir</span></span>' +
            i('chevron-down', 'hidden size-4 text-muted-foreground sm:block') +
          '</button>' +
          '<div class="popover end-0 w-56 p-1.5" data-popover-panel data-open="false" role="menu">' +
            menuLink('profile.html', 'user', 'پروفایل من') +
            menuLink('settings.html#billing', 'card', 'صورتحساب') +
            menuLink('settings.html', 'settings', 'تنظیمات') +
            menuLink('messages.html', 'help', 'پشتیبانی') +
            '<div class="my-1 h-px bg-border"></div>' +
            menuLink('login.html', 'logout', 'خروج', 'text-danger hover:bg-danger/10') +
          '</div>' +
        '</div>' +
      '</div>' +
    '</header>';

  const overlays =
    '<div class="fixed inset-0 z-[60] hidden" data-cmdk role="dialog" aria-modal="true" aria-label="جستجو">' +
      '<div class="absolute inset-0 bg-black/40 backdrop-blur-sm animate-fade-in" data-cmdk-close></div>' +
      '<div class="relative mx-auto mt-[12vh] w-[min(36rem,calc(100vw-2rem))] overflow-hidden rounded-2xl border bg-popover shadow-elevation-3 animate-scale-in">' +
        '<div class="flex items-center gap-3 border-b px-4">' + i('search', 'size-5 text-muted-foreground') +
          '<input type="text" class="h-14 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground" placeholder="دنبال چه چیزی هستید؟" data-cmdk-input aria-label="عبارت جستجو">' +
          '<kbd class="kbd">Esc</kbd></div>' +
        '<ul class="max-h-80 overflow-y-auto p-2" data-cmdk-list role="listbox"></ul>' +
        '<div class="flex items-center gap-4 border-t bg-muted/40 px-4 py-2.5 text-[11px] text-muted-foreground">' +
          '<span class="flex items-center gap-1"><kbd class="kbd">↵</kbd>انتخاب</span>' +
          '<span class="flex items-center gap-1"><kbd class="kbd">↑</kbd><kbd class="kbd">↓</kbd>جابه‌جایی</span>' +
        '</div>' +
      '</div>' +
    '</div>';

  const toasts = '<div class="pointer-events-none fixed bottom-4 start-4 z-[70] flex flex-col gap-2" data-toasts aria-live="polite"></div>';

  /* ---------- درج در صفحه ---------- */
  const main = document.querySelector('.app-main');
  const isApp = !!main;

  if (isApp) {
    document.body.insertAdjacentHTML('afterbegin',
      '<a href="#main" class="sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-[100] btn btn-primary">پرش به محتوا</a>' + background + sidebar);
    main.insertAdjacentHTML('afterbegin', header);
    document.body.insertAdjacentHTML('beforeend', overlays);

    const list = document.querySelector('[data-notifications]');
    const tone = Nava.data.tone;
    list.innerHTML = Nava.data.notifications.map((n) =>
      '<li><a href="' + n.href + '" class="flex gap-3 px-4 py-3 transition-colors hover:bg-muted/60">' +
        '<span class="grid size-9 shrink-0 place-items-center rounded-full ' + tone[n.color] + '">' + i(n.icon, 'size-4') + '</span>' +
        '<div class="flex-1 text-sm leading-6"><p>' + n.text + '</p><p class="text-[11px] text-muted-foreground">' + n.time + '</p></div>' +
        (n.unread ? '<span class="mt-2 size-2 shrink-0 rounded-full bg-accent" data-unread></span>' : '') +
      '</a></li>'
    ).join('');
    document.querySelector('[data-notif-read]').addEventListener('click', () => {
      list.querySelectorAll('[data-unread]').forEach((d) => d.remove());
    });
  }
  document.body.insertAdjacentHTML('beforeend', toasts);
  Nava.icons.render();

  Nava.layout = { NAV, pages: ALL_PAGES, page };
})(window.Nava);
