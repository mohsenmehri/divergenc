/**
 * صفحه‌ی پروفایل: آمار شخصی، درصد تکمیل و خط زمانی فعالیت‌ها
 */
(function (Nava) {
  'use strict';
  const { $, $$, fa } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const { ui, effects } = Nava;

  ui.render.stats($('[data-stats]'), [
    { label: 'سفارش‌های پردازش‌شده', value: 1284, icon: 'bag', tone: 'primary' },
    { label: 'محصولات افزوده‌شده', value: 86, icon: 'package', tone: 'accent' },
    { label: 'پاسخ به پیام‌ها', value: 412, icon: 'message', tone: 'info' },
    { label: 'امتیاز رضایت', value: 4.9, decimals: 1, icon: 'star', tone: 'warning' },
  ]);

  const bar = $('[data-complete]');
  effects.onVisible(bar, () => {
    bar.style.width = '75%';
    effects.countUp($('[data-complete-label]'), 75, { suffix: '٪', duration: 1400 });
  });

  const ACTIVITY = [
    { type: 'order', icon: 'truck', title: 'وضعیت ۳ سفارش را به «ارسال شد» تغییر داد', time: '۱۰ دقیقه پیش', href: 'orders.html' },
    { type: 'product', icon: 'plus', title: 'محصول «هدست گیمینگ» را اضافه کرد', time: '۲ ساعت پیش', href: 'products.html' },
    { type: 'order', icon: 'check', title: 'سفارش #۸۴۱۸ را تأیید کرد', time: '۵ ساعت پیش', href: 'orders.html' },
    { type: 'product', icon: 'edit', title: 'قیمت «ساعت هوشمند سری ۹» را به‌روزرسانی کرد', time: 'دیروز', href: 'products.html' },
    { type: 'other', icon: 'file', title: 'گزارش «سود و زیان شهریور» را دانلود کرد', time: 'دیروز', href: 'reports.html' },
    { type: 'other', icon: 'user-plus', title: 'پریا اکبری را به تیم دعوت کرد', time: '۲ روز پیش', href: 'settings.html#team' },
    { type: 'order', icon: 'x', title: 'سفارش #۸۴۱۷ را لغو کرد', time: '۳ روز پیش', href: 'orders.html' },
  ];
  function render(filter) {
    $('[data-timeline]').innerHTML = ACTIVITY.filter((a) => filter === 'all' || a.type === filter).map((a, i) =>
      '<li class="relative flex gap-4" style="animation:fade-up .5s cubic-bezier(.16,1,.3,1) ' + i * 60 + 'ms both">' +
        '<span class="relative z-10 grid size-10 shrink-0 place-items-center rounded-full border bg-card ring-4 ring-card ' + (i === 0 ? 'text-accent' : 'text-muted-foreground') + '">' + icon(a.icon, 'size-4') + '</span>' +
        '<a href="' + a.href + '" class="group -m-2 flex-1 rounded-xl p-2 transition-colors hover:bg-muted/50">' +
          '<p class="text-sm font-medium">' + a.title + '</p><p class="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">' + icon('clock', 'size-3') + a.time +
          '<span class="ms-auto opacity-0 transition-opacity group-hover:opacity-100">' + icon('chevron-left', 'size-4') + '</span></p>' +
        '</a>' +
      '</li>'
    ).join('');
  }
  ui.segmented($('[data-activity-filter]'), render);
  render('all');
  effects.reveal();
})(window.Nava);
