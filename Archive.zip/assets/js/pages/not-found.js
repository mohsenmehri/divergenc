/**
 * صفحه‌ی ۴۰۴: پارالاکس ملایم عدد با حرکت ماوس
 */
(function (Nava) {
  'use strict';
  if (Nava.utils.prefersReducedMotion()) return;
  const layers = Nava.utils.$$('[data-depth]');
  document.addEventListener('pointermove', (e) => {
    const x = e.clientX / innerWidth - 0.5;
    const y = e.clientY / innerHeight - 0.5;
    layers.forEach((l) => { l.style.translate = (x * l.dataset.depth) + 'px ' + (y * l.dataset.depth) + 'px'; });
  });
})(window.Nava);
