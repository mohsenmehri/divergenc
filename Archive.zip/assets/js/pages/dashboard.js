/**
 * صفحه‌ی داشبورد — داده‌های نمونه و راه‌اندازی ویجت‌ها
 * در نسخه‌ی واقعی، داده‌ها از API دریافت می‌شوند.
 */
(function (Nava) {
  'use strict';
  const { $, $$, fa, faDigits, jalali, escape, debounce } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const { effects, charts } = Nava;

  /* ------------------------------------------------------------------
     داده‌های نمونه
     ------------------------------------------------------------------ */
  const DATA = {
    kpis: [
      { title: 'درآمد کل', value: 1928.4, decimals: 1, suffix: ' م', unit: 'میلیون تومان', trend: 12.5, icon: 'wallet', color: 'chart-1', spark: [12, 18, 14, 22, 19, 27, 24, 31, 29, 36] },
      { title: 'سفارش‌ها', value: 3842, unit: 'سفارش این ماه', trend: 8.2, icon: 'bag', color: 'chart-2', spark: [20, 16, 24, 21, 28, 25, 30, 27, 33, 35] },
      { title: 'کاربران جدید', value: 1264, unit: 'ثبت‌نام این ماه', trend: 23.1, icon: 'user-plus', color: 'chart-4', spark: [8, 12, 10, 15, 14, 19, 22, 20, 26, 30] },
      { title: 'نرخ تبدیل', value: 3.62, decimals: 2, suffix: '٪', unit: 'از کل بازدیدها', trend: -1.4, icon: 'percent', color: 'chart-5', spark: [30, 28, 31, 26, 27, 24, 25, 23, 24, 22] },
    ],
    revenue: {
      week: {
        labels: ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'],
        series: [[62, 78, 71, 95, 88, 112, 104], [38, 44, 40, 52, 47, 58, 55]],
        total: 610, trend: 6.4,
      },
      month: {
        labels: Array.from({ length: 30 }, (_, i) => faDigits(i + 1) + ' مهر'),
        series: [
          [42, 48, 45, 52, 58, 55, 61, 66, 60, 68, 72, 70, 76, 81, 78, 74, 82, 88, 85, 92, 96, 90, 98, 104, 99, 108, 112, 106, 115, 121],
          [28, 30, 29, 33, 35, 34, 37, 39, 36, 41, 43, 42, 44, 47, 45, 44, 48, 50, 49, 52, 54, 51, 55, 58, 56, 60, 62, 59, 63, 66],
        ],
        total: 1928.4, trend: 12.5,
      },
      year: {
        labels: ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'],
        series: [[980, 1120, 1060, 1290, 1380, 1310, 1928, 1650, 1720, 1840, 1960, 2240], [620, 680, 650, 740, 790, 760, 980, 880, 910, 960, 1010, 1120]],
        total: 18078, trend: 18.9,
      },
    },
    traffic: [
      { label: 'جستجوی گوگل', value: 4820, color: 'chart-1', icon: 'search' },
      { label: 'شبکه‌های اجتماعی', value: 3150, color: 'chart-2', icon: 'globe' },
      { label: 'ورود مستقیم', value: 2240, color: 'chart-3', icon: 'zap' },
      { label: 'ایمیل و پیامک', value: 1190, color: 'chart-4', icon: 'message' },
    ],
    orders: Nava.data.orders.slice(0, 6).map((o) => Object.assign({ name: o.customer }, o)),
    status: Nava.data.status,
    activity: [
      { icon: 'bag', color: 'primary', title: 'سفارش جدید ثبت شد', desc: 'سارا محمدی — هدفون بی‌سیم پرو', time: '۲ دقیقه پیش' },
      { icon: 'user-plus', color: 'info', title: 'کاربر جدید', desc: '۱۸ کاربر امروز ثبت‌نام کردند', time: '۱۵ دقیقه پیش' },
      { icon: 'truck', color: 'accent', title: 'ارسال سفارش', desc: 'سفارش #۸۴۲۰ به پست تحویل شد', time: '۱ ساعت پیش' },
      { icon: 'star', color: 'warning', title: 'نظر ۵ ستاره', desc: '«کیفیت عالی و ارسال سریع»', time: '۳ ساعت پیش' },
      { icon: 'x', color: 'danger', title: 'لغو سفارش', desc: 'سفارش #۸۴۱۷ توسط مشتری لغو شد', time: '۵ ساعت پیش' },
    ],
    products: [
      { name: 'هدفون بی‌سیم پرو', sold: 842, revenue: '۴٫۰ میلیارد', pct: 92, icon: 'headphones', color: 'primary' },
      { name: 'ساعت هوشمند سری ۹', sold: 611, revenue: '۷٫۹ میلیارد', pct: 74, icon: 'watch', color: 'accent' },
      { name: 'گوشی هوشمند X', sold: 438, revenue: '۱۶٫۸ میلیارد', pct: 58, icon: 'smartphone', color: 'info' },
      { name: 'کیبورد مکانیکی', sold: 327, revenue: '۱٫۰ میلیارد', pct: 41, icon: 'keyboard', color: 'warning' },
    ],
    weekly: { labels: ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'], values: [182, 214, 196, 268, 241, 312, 224] },
  };

  const tone = Nava.data.tone;
  const toman = (n) => fa(n) + ' <span class="text-[11px] text-muted-foreground">تومان</span>';
  const initials = (name) => name.trim()[0];

  /* ------------------------------------------------------------------
     خوشامد و تاریخ
     ------------------------------------------------------------------ */
  function renderGreeting() {
    const hr = new Date().getHours();
    $('[data-greeting]').textContent = hr < 12 ? 'صبح بخیر' : hr < 17 ? 'ظهر بخیر' : hr < 20 ? 'عصر بخیر' : 'شب بخیر';
    $('[data-today]').textContent = jalali();
  }

  /* ------------------------------------------------------------------
     کارت‌های شاخص
     ------------------------------------------------------------------ */
  function renderKpis() {
    const wrap = $('[data-kpis]');
    wrap.innerHTML = DATA.kpis.map((k, i) => {
      const up = k.trend >= 0;
      return (
        '<article class="card card-hover reveal p-5" style="--delay:' + i * 90 + 'ms" data-kpi="' + i + '">' +
          '<div class="flex items-start justify-between">' +
            '<span class="grid size-11 place-items-center rounded-xl shadow-elevation-2" style="color:hsl(var(--background));background:linear-gradient(135deg,hsl(var(--' + k.color + ')),hsl(var(--' + k.color + ') / .75))">' + icon(k.icon, 'size-5') + '</span>' +
            '<span class="badge ' + (up ? 'badge-primary' : 'badge-danger') + '">' + icon(up ? 'arrow-up' : 'arrow-down', 'size-3.5') + fa(Math.abs(k.trend), 1) + '٪</span>' +
          '</div>' +
          '<p class="mt-4 text-sm text-muted-foreground">' + escape(k.title) + '</p>' +
          '<div class="mt-1 flex items-end justify-between gap-3">' +
            '<div><p class="text-2xl font-extrabold tracking-tight tabular" data-count>۰</p>' +
            '<p class="mt-1 text-[11px] text-muted-foreground">' + escape(k.unit) + '</p></div>' +
            '<div class="h-10 w-24 shrink-0" data-spark></div>' +
          '</div>' +
        '</article>'
      );
    }).join('');

    $$('[data-kpi]', wrap).forEach((card) => {
      const k = DATA.kpis[+card.dataset.kpi];
      const spark = charts.sparkline($('[data-spark]', card), { values: k.spark, color: k.color });
      effects.tilt(card, 5);
      effects.onVisible(card, () => {
        effects.countUp($('[data-count]', card), k.value, { decimals: k.decimals || 0, suffix: k.suffix || '' });
        spark.play();
      });
    });
  }

  /* ------------------------------------------------------------------
     نمودار درآمد + کنترل بخش‌بندی‌شده
     ------------------------------------------------------------------ */
  function revenueConfig(key) {
    const r = DATA.revenue[key];
    return {
      labels: r.labels,
      series: [
        { name: 'درآمد', color: 'chart-1', values: r.series[0] },
        { name: 'هزینه‌ها', color: 'chart-2', values: r.series[1] },
      ],
    };
  }

  function renderRevenueSummary(key) {
    const r = DATA.revenue[key];
    effects.countUp($('[data-revenue-total]'), r.total, { duration: 900, decimals: r.total % 1 ? 1 : 0 });
    const b = $('[data-revenue-trend]');
    b.innerHTML = icon('arrow-up', 'size-3.5') + fa(r.trend, 1) + '٪';
  }

  function initRevenue() {
    const host = $('[data-chart="revenue"]');
    const chart = charts.areaChart(host, revenueConfig('month'));
    effects.onVisible(host, () => { chart.play(); renderRevenueSummary('month'); });
    Nava.ui.segmented($('[data-segmented="revenue"]'), (key) => { chart.update(revenueConfig(key)); renderRevenueSummary(key); });
  }

  /* ------------------------------------------------------------------
     منابع ترافیک
     ------------------------------------------------------------------ */
  function initTraffic() {
    const total = DATA.traffic.reduce((a, t) => a + t.value, 0);
    const legend = $('[data-traffic-legend]');
    legend.innerHTML = DATA.traffic.map((t, i) =>
      '<li class="flex cursor-default items-center gap-3 rounded-lg p-1.5 transition-colors" data-i="' + i + '">' +
        '<span class="grid size-8 place-items-center rounded-lg" style="background:hsl(var(--' + t.color + ') / .12);color:hsl(var(--' + t.color + '))">' + icon(t.icon, 'size-4') + '</span>' +
        '<span class="flex-1">' + escape(t.label) + '</span>' +
        '<span class="text-muted-foreground tabular">' + fa(t.value) + '</span>' +
        '<span class="w-10 text-end font-semibold tabular">' + fa(Math.round((t.value / total) * 100)) + '٪</span>' +
      '</li>'
    ).join('');

    const items = $$('li', legend);
    const donut = charts.donutChart($('[data-chart="traffic"]'), {
      segments: DATA.traffic,
      centerLabel: 'بازدید کل',
      onHover: (i) => items.forEach((li, j) => li.classList.toggle('bg-muted', j === i)),
    });
    items.forEach((li, i) => {
      li.addEventListener('pointerenter', () => donut.highlight(i));
      li.addEventListener('pointerleave', () => donut.highlight(-1));
    });
    effects.onVisible($('[data-chart="traffic"]'), donut.play);
  }

  /* ------------------------------------------------------------------
     سفارش‌ها (جدول دسکتاپ + کارت موبایل)
     ------------------------------------------------------------------ */
  function renderOrders(query) {
    const q = (query || '').trim();
    const rows = DATA.orders.filter((o) => !q || (o.name + o.product + o.id + o.city).includes(q));
    const st = (o) => DATA.status[o.status];
    const avatar = (o, i) => '<span class="grid size-9 shrink-0 place-items-center rounded-full text-sm font-bold" style="background:hsl(var(--chart-' + ((i % 5) + 1) + ') / .14);color:hsl(var(--chart-' + ((i % 5) + 1) + '))">' + initials(o.name) + '</span>';

    $('[data-orders-table]').innerHTML = rows.map((o, i) =>
      '<tr class="group transition-colors hover:bg-muted/40" style="animation:fade-up .5s cubic-bezier(.16,1,.3,1) ' + i * 50 + 'ms both">' +
        '<td class="px-5 py-3.5 font-medium tabular text-muted-foreground">' + o.id + '</td>' +
        '<td class="px-5 py-3.5"><div class="flex items-center gap-3">' + avatar(o, i) + '<div><p class="font-medium">' + escape(o.name) + '</p><p class="text-xs text-muted-foreground">' + escape(o.city) + '</p></div></div></td>' +
        '<td class="px-5 py-3.5 text-muted-foreground">' + escape(o.product) + '</td>' +
        '<td class="whitespace-nowrap px-5 py-3.5 font-semibold tabular">' + toman(o.amount) + '</td>' +
        '<td class="px-5 py-3.5"><span class="badge badge-dot ' + st(o).cls + '">' + st(o).label + '</span></td>' +
        '<td class="px-5 py-3.5 text-end"><a href="orders.html" class="btn-icon size-8 opacity-0 transition group-hover:opacity-100 focus:opacity-100" aria-label="جزئیات">' + icon('eye', 'size-4') + '</a></td>' +
      '</tr>'
    ).join('');

    $('[data-orders-list]').innerHTML = rows.map((o, i) =>
      '<li class="flex items-center gap-3 p-4" style="animation:fade-up .5s cubic-bezier(.16,1,.3,1) ' + i * 50 + 'ms both">' +
        avatar(o, i) +
        '<div class="min-w-0 flex-1"><div class="flex items-center justify-between gap-2"><p class="truncate font-medium">' + escape(o.name) + '</p><span class="badge ' + st(o).cls + '">' + st(o).label + '</span></div>' +
        '<div class="mt-1 flex items-center justify-between gap-2 text-xs text-muted-foreground"><span class="truncate">' + o.id + ' · ' + escape(o.product) + '</span><span class="shrink-0 font-semibold text-foreground tabular">' + fa(o.amount) + '</span></div></div>' +
      '</li>'
    ).join('');

    $('[data-orders-empty]').classList.toggle('hidden', rows.length > 0);
  }

  function initOrders() {
    renderOrders();
    $('[data-orders-search]').addEventListener('input', debounce((e) => renderOrders(e.target.value), 150));
  }

  /* ------------------------------------------------------------------
     فعالیت‌ها، محصولات، اعلان‌ها
     ------------------------------------------------------------------ */
  function renderActivity() {
    const list = $('[data-activity]');
    list.innerHTML = DATA.activity.map((a, i) =>
      '<li class="reveal relative flex gap-3" style="--delay:' + (i * 80) + 'ms">' +
        '<span class="relative z-10 grid size-8 shrink-0 place-items-center rounded-full ring-4 ring-card ' + tone[a.color] + '">' + icon(a.icon, 'size-4') + '</span>' +
        '<div class="min-w-0 flex-1 pt-0.5"><div class="flex items-center justify-between gap-2"><p class="text-sm font-semibold">' + escape(a.title) + '</p><time class="shrink-0 text-[11px] text-muted-foreground">' + a.time + '</time></div>' +
        '<p class="mt-0.5 truncate text-xs text-muted-foreground">' + escape(a.desc) + '</p></div>' +
      '</li>'
    ).join('');
  }

  function renderProducts() {
    const list = $('[data-top-products]');
    list.innerHTML = DATA.products.map((p) =>
      '<li class="group flex items-center gap-3">' +
        '<span class="grid size-11 shrink-0 place-items-center rounded-xl transition-transform duration-300 ease-spring group-hover:-rotate-6 group-hover:scale-110 ' + tone[p.color] + '">' + icon(p.icon, 'size-5') + '</span>' +
        '<div class="min-w-0 flex-1">' +
          '<div class="flex items-center justify-between gap-2 text-sm"><p class="truncate font-medium">' + escape(p.name) + '</p><p class="shrink-0 font-semibold">' + p.revenue + '</p></div>' +
          '<div class="mt-2 flex items-center gap-3"><div class="progress"><span style="background:hsl(var(--' + p.color + '))" data-w="' + p.pct + '"></span></div>' +
          '<span class="shrink-0 text-[11px] text-muted-foreground tabular">' + fa(p.sold) + ' فروش</span></div>' +
        '</div>' +
      '</li>'
    ).join('');
    effects.onVisible(list, () => $$('[data-w]', list).forEach((bar, i) => setTimeout(() => (bar.style.width = bar.dataset.w + '%'), i * 120)));
  }

  function initSmallCharts() {
    const weeklyHost = $('[data-chart="weekly"]');
    const weekly = charts.barChart(weeklyHost, { labels: DATA.weekly.labels, values: DATA.weekly.values, unit: 'سفارش' });
    effects.onVisible(weeklyHost, weekly.play);

    const goalHost = $('[data-chart="goal"]');
    const goal = charts.gauge(goalHost, { value: 76, label: 'از هدف مهر ماه' });
    effects.onVisible(goalHost, goal.play);
  }

  /* ------------------------------------------------------------------
     راه‌اندازی
     ------------------------------------------------------------------ */
  renderGreeting();
  renderKpis();
  initRevenue();
  initTraffic();
  initOrders();
  renderActivity();
  renderProducts();
  initSmallCharts();
  effects.reveal();

  setTimeout(() => Nava.toast('به پنل مدیریت نوا خوش آمدید 👋', { type: 'info' }), 1200);
})(window.Nava);
