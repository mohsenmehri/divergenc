/**
 * صفحه‌ی سفارش‌ها: فیلتر وضعیت، جستجو، مرتب‌سازی، انتخاب گروهی، جزئیات و ثبت سفارش
 */
(function (Nava) {
  'use strict';
  const { $, fa, escape } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const { ui, forms, effects } = Nava;
  const { render } = ui;
  const D = Nava.data;
  const orders = D.orders.map((o, i) => Object.assign({ idNum: 8421 - i }, o));

  /* ---------- آمار ---------- */
  const count = (st) => orders.filter((o) => o.status === st).length;
  function renderStats() {
    render.stats($('[data-stats]'), [
      { label: 'کل سفارش‌ها', value: orders.length, icon: 'bag', tone: 'primary' },
      { label: 'در انتظار تأیید', value: count('pending'), icon: 'clock', tone: 'warning' },
      { label: 'در حال ارسال', value: count('shipping'), icon: 'truck', tone: 'info' },
      { label: 'لغو شده', value: count('canceled'), icon: 'x-circle', tone: 'danger' },
    ]);
  }

  /* ---------- جدول ---------- */
  let bulkSelection = [];
  const badge = (o) => '<span class="badge badge-dot ' + D.status[o.status].cls + '">' + D.status[o.status].label + '</span>';
  const table = Nava.dataTable({
    rows: orders,
    pageSize: 8,
    searchKeys: ['id', 'customer', 'product', 'city'],
    head: $('[data-head]'),
    tbody: $('[data-tbody]'),
    list: $('[data-list]'),
    empty: $('[data-empty]'),
    pager: $('[data-pager]'),
    info: $('[data-info]'),
    selectAll: $('[data-select-all]'),
    scrollTarget: $('[data-table-card]'),
    row: (o, i, sel) =>
      '<tr class="' + (sel ? 'is-selected' : '') + '" style="animation:fade-up .45s cubic-bezier(.16,1,.3,1) ' + i * 35 + 'ms both">' +
        '<td><input type="checkbox" class="checkbox" data-select="' + orders.indexOf(o) + '"' + (sel ? ' checked' : '') + ' aria-label="انتخاب ' + o.id + '"></td>' +
        '<td class="font-medium tabular text-muted-foreground">' + o.id + '</td>' +
        '<td><div class="flex items-center gap-3">' + render.avatar(o.customer) + '<div><p class="font-medium">' + escape(o.customer) + '</p><p class="text-xs text-muted-foreground">' + escape(o.city) + '</p></div></div></td>' +
        '<td><div class="flex items-center gap-2 text-muted-foreground">' + icon(o.productIcon, 'size-4') + escape(o.product) + (o.qty > 1 ? ' <span class="badge badge-muted">×' + fa(o.qty) + '</span>' : '') + '</div></td>' +
        '<td class="text-muted-foreground">' + o.date + '</td>' +
        '<td class="text-muted-foreground">' + o.payment + '</td>' +
        '<td class="font-semibold tabular">' + render.money(o.amount) + '</td>' +
        '<td>' + badge(o) + '</td>' +
        '<td class="text-end"><button type="button" class="btn-icon size-8" data-view="' + orders.indexOf(o) + '" aria-label="جزئیات">' + icon('eye', 'size-4') + '</button></td>' +
      '</tr>',
    card: (o, i) =>
      '<li style="animation:fade-up .45s cubic-bezier(.16,1,.3,1) ' + i * 35 + 'ms both"><button type="button" class="flex w-full items-center gap-3 p-4 text-start" data-view="' + orders.indexOf(o) + '">' +
        render.avatar(o.customer) +
        '<div class="min-w-0 flex-1"><div class="flex items-center justify-between gap-2"><p class="truncate font-medium">' + escape(o.customer) + '</p>' + badge(o) + '</div>' +
        '<div class="mt-1 flex items-center justify-between gap-2 text-xs text-muted-foreground"><span class="truncate">' + o.id + ' · ' + escape(o.product) + '</span><span class="shrink-0 font-semibold text-foreground tabular">' + fa(o.amount) + '</span></div></div>' +
      '</button></li>',
    onSelect: (sel) => {
      $('[data-bulk]').style.gridTemplateRows = sel.length ? '1fr' : '0fr';
      $('[data-bulk-count]').textContent = fa(sel.length);
      bulkSelection = sel;
    },
  });

  $('[data-search]').addEventListener('input', Nava.utils.debounce((e) => table.search(e.target.value), 150));

  /* ---------- فیلتر وضعیت ---------- */
  let chips;
  function renderChips() {
    const items = [{ value: 'all', label: 'همه', n: orders.length }].concat(
      Object.keys(D.status).map((k) => ({ value: k, label: D.status[k].label, n: count(k) }))
    );
    const root = $('[data-chips]');
    const current = (root.querySelector('[aria-pressed="true"]') || {}).dataset;
    root.innerHTML = items.map((c) =>
      '<button type="button" class="chip" data-value="' + c.value + '" aria-pressed="' + ((current ? current.value : 'all') === c.value) + '">' + c.label + '<span class="chip-count">' + fa(c.n) + '</span></button>'
    ).join('');
    chips = ui.chips(root, (v) => table.filter(v === 'all' ? null : (o) => o.status === v));
  }
  renderChips();
  if (location.hash === '#pending') chips.set('pending');

  /* ---------- عملیات گروهی ---------- */
  $('[data-bulk-ship]').addEventListener('click', () => {
    bulkSelection.forEach((o) => { o.status = 'shipping'; });
    Nava.toast(fa(bulkSelection.length) + ' سفارش به «در حال ارسال» تغییر کرد');
    table.clearSelection(); renderChips(); renderStats();
  });
  $('[data-bulk-delete]').addEventListener('click', () => {
    const n = bulkSelection.length;
    table.remove(bulkSelection.slice());
    Nava.toast(fa(n) + ' سفارش حذف شد', { type: 'error' });
    renderChips(); renderStats();
  });

  /* ---------- خروجی CSV ---------- */
  $('[data-export]').addEventListener('click', () => {
    ui.downloadCSV('orders.csv', [['شماره', 'مشتری', 'شهر', 'محصول', 'تعداد', 'مبلغ (تومان)', 'تاریخ', 'پرداخت', 'وضعیت']].concat(
      table.view.map((o) => [o.id, o.customer, o.city, o.product, o.qty, o.amount, o.date, o.payment, D.status[o.status].label])
    ));
    Nava.toast('فایل CSV دانلود شد');
  });

  /* ---------- کشوی جزئیات ---------- */
  const drawer = ui.overlay('order-drawer');
  const STEPS = ['ثبت سفارش', 'پرداخت', 'آماده‌سازی', 'ارسال', 'تحویل'];
  const reached = { pending: 1, paid: 2, shipping: 4, delivered: 5, canceled: 1 };

  function openOrder(o) {
    $('[data-d="id"]').textContent = 'سفارش ' + o.id;
    const unit = o.amount / o.qty;
    const ship = o.amount > 10000000 ? 0 : 85000;
    const done = reached[o.status];
    $('[data-drawer-body]').innerHTML =
      '<div class="flex items-center justify-between">' + badge(o) + '<span class="text-xs text-muted-foreground">' + o.date + '</span></div>' +

      '<section class="flex items-center gap-3 rounded-xl border p-4">' + render.avatar(o.customer, 'size-12 text-base') +
        '<div class="min-w-0 flex-1"><p class="font-semibold">' + escape(o.customer) + '</p><p class="truncate text-xs text-muted-foreground" dir="ltr">' + o.email + '</p>' +
        '<p class="mt-1 flex items-center gap-1 text-xs text-muted-foreground">' + icon('map-pin', 'size-3.5') + escape(o.city) + '</p></div>' +
        '<a href="customers.html" class="btn-icon" aria-label="پروفایل مشتری">' + icon('external', 'size-4') + '</a></section>' +

      '<section><h3 class="mb-3 text-sm font-semibold">اقلام سفارش</h3>' +
        '<div class="flex items-center gap-3 rounded-xl bg-muted/50 p-3"><span class="grid size-12 place-items-center rounded-lg bg-card">' + icon(o.productIcon, 'size-5') + '</span>' +
        '<div class="flex-1"><p class="text-sm font-medium">' + escape(o.product) + '</p><p class="text-xs text-muted-foreground">' + fa(o.qty) + ' × ' + fa(unit) + ' تومان</p></div>' +
        '<b class="text-sm tabular">' + fa(o.amount) + '</b></div>' +
        '<dl class="mt-4 space-y-2 text-sm">' +
          '<div class="flex justify-between"><dt class="text-muted-foreground">جمع اقلام</dt><dd class="tabular">' + fa(o.amount) + '</dd></div>' +
          '<div class="flex justify-between"><dt class="text-muted-foreground">هزینه ارسال</dt><dd class="tabular">' + (ship ? fa(ship) : 'رایگان') + '</dd></div>' +
          '<div class="flex justify-between"><dt class="text-muted-foreground">روش پرداخت</dt><dd>' + o.payment + '</dd></div>' +
          '<div class="flex justify-between border-t pt-2 text-base font-bold"><dt>مبلغ کل</dt><dd class="tabular">' + render.money(o.amount + ship) + '</dd></div>' +
        '</dl></section>' +

      '<section><h3 class="mb-4 text-sm font-semibold">روند سفارش</h3><ol class="space-y-4">' +
        STEPS.map((s, i) => {
          const on = i < done, cancel = o.status === 'canceled' && i === 1;
          return '<li class="relative flex items-center gap-3" style="animation:fade-up .5s cubic-bezier(.16,1,.3,1) ' + (0.15 + i * 0.08) + 's both">' +
            (i < STEPS.length - 1 ? '<span class="absolute start-[13px] top-7 h-4 w-0.5 ' + (i < done - 1 ? 'bg-primary' : 'bg-border') + '"></span>' : '') +
            '<span class="grid size-7 place-items-center rounded-full ' + (cancel ? 'bg-danger text-white' : on ? 'bg-primary text-primary-foreground' : 'border bg-card text-muted-foreground') + '">' +
              icon(cancel ? 'x' : on ? 'check' : 'clock', 'size-3.5') + '</span>' +
            '<span class="text-sm ' + (on || cancel ? 'font-medium' : 'text-muted-foreground') + '">' + (cancel ? 'لغو شده توسط مشتری' : s) + '</span></li>';
        }).join('') +
      '</ol></section>' +

      '<section><h3 class="mb-2 text-sm font-semibold">تغییر وضعیت</h3><select class="input" data-status-select aria-label="وضعیت سفارش">' +
        Object.keys(D.status).map((k) => '<option value="' + k + '"' + (k === o.status ? ' selected' : '') + '>' + D.status[k].label + '</option>').join('') +
      '</select></section>';

    $('[data-status-select]').addEventListener('change', (e) => {
      o.status = e.target.value;
      table.refresh(); renderChips(); renderStats();
      Nava.toast('وضعیت ' + o.id + ' به «' + D.status[o.status].label + '» تغییر کرد');
      openOrder(o);
    });
    drawer.open();
  }
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-view]');
    if (b) openOrder(orders[+b.dataset.view]);
  });

  /* ---------- سفارش جدید ---------- */
  const modal = ui.overlay('order-modal');
  const form = $('[data-order-form]');
  $('[data-customers]').innerHTML = '<option value="">انتخاب مشتری…</option>' + D.customers.map((c, i) => '<option value="' + i + '">' + escape(c.name) + ' — ' + c.city + '</option>').join('');
  $('[data-products]').innerHTML = '<option value="">انتخاب محصول…</option>' + D.products.filter((p) => p.stock > 0).map((p) => '<option value="' + p.id + '">' + escape(p.name) + '</option>').join('');
  const total = () => {
    const p = D.products.find((x) => x.id === +$('#o-product').value);
    $('[data-order-total]').innerHTML = p ? render.money(p.price * Math.max(1, +$('#o-qty').value || 1)) : '۰';
  };
  $('#o-product').addEventListener('change', total);
  $('#o-qty').addEventListener('input', total);

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!forms.validate(form)) return;
    const c = D.customers[+$('#o-customer').value];
    const p = D.products.find((x) => x.id === +$('#o-product').value);
    const qty = Math.max(1, +$('#o-qty').value || 1);
    const idNum = Math.max.apply(null, orders.map((o) => o.idNum)) + 1;
    orders.unshift({
      idNum, id: '#' + Nava.utils.faDigits(idNum), customer: c.name, email: c.email, city: c.city,
      product: p.name, productIcon: p.icon, qty, amount: p.price * qty, status: 'pending',
      payment: $('#o-pay').value, date: '۲۲ مهر ۱۴۰۵',
    });
    modal.close();
    form.reset(); total();
    chips.set('all');
    renderChips(); renderStats();
    Nava.toast('سفارش ' + orders[0].id + ' با موفقیت ثبت شد');
  });

  renderStats();
  effects.reveal();
})(window.Nava);
