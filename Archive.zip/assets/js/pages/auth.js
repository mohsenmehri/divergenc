/**
 * صفحات احراز هویت: ورود، ثبت‌نام و بازیابی رمز
 * (نسخه‌ی نمایشی — درخواست‌ها شبیه‌سازی می‌شوند و به API واقعی ارسال نمی‌شوند)
 */
(function (Nava) {
  'use strict';
  const { $, $$, fa, prefersReducedMotion } = Nava.utils;
  const { forms, effects } = Nava;
  const page = document.body.dataset.page;
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ------------------------------------------------------------------
     بخش تصویری سمت چپ (مشترک بین صفحات)
     ------------------------------------------------------------------ */
  function renderArt() {
    const art = $('[data-auth-art]');
    if (!art) return;
    const bars = [38, 52, 44, 68, 57, 82, 74, 96];
    art.innerHTML =
      '<div class="orb -start-24 -top-24 size-[28rem] bg-accent/40"></div>' +
      '<div class="orb -bottom-32 end-0 size-[24rem] bg-warning/20 [animation-delay:-5s]"></div>' +
      '<div class="orb start-1/3 top-1/2 size-64 bg-white/10 [animation-delay:-9s]"></div>' +
      '<div class="absolute inset-0 [background-image:linear-gradient(rgb(255_255_255/.05)_1px,transparent_1px),linear-gradient(90deg,rgb(255_255_255/.05)_1px,transparent_1px)] [background-size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]"></div>' +

      '<div class="relative z-10 flex items-center gap-2 p-10 text-sm text-white/70">' +
        '<span class="size-2 animate-pulse rounded-full bg-accent"></span>همه‌ی سیستم‌ها فعال هستند' +
      '</div>' +

      // کارت‌های شناور
      '<div class="relative z-10 flex flex-1 items-center justify-center px-10" data-parallax>' +
        '<div class="relative w-full max-w-md">' +
          '<div class="auth-card-float rounded-2xl border border-white/10 bg-white/[.06] p-6 shadow-2xl backdrop-blur-xl" data-depth="12">' +
            '<div class="flex items-center justify-between">' +
              '<p class="text-sm text-white/60">درآمد امروز</p>' +
              '<span class="rounded-full bg-accent/20 px-2 py-0.5 text-xs font-medium text-accent">+۱۲٫۵٪</span>' +
            '</div>' +
            '<p class="mt-2 text-4xl font-extrabold tabular" data-art-count>۰</p>' +
            '<p class="text-xs text-white/50">میلیون تومان</p>' +
            '<div class="mt-6 flex h-28 items-end gap-2">' +
              bars.map((h, i) =>
                '<span class="flex-1 origin-bottom rounded-md ' + (i === bars.length - 1 ? 'bg-accent' : 'bg-white/20') + '" style="height:' + h + '%;animation:art-bar 1s cubic-bezier(.34,1.3,.64,1) ' + (0.4 + i * 0.07) + 's both"></span>'
              ).join('') +
            '</div>' +
          '</div>' +

          '<div class="absolute -end-6 -top-10 flex items-center gap-3 rounded-xl border border-white/10 bg-zinc-900/90 p-3 pe-5 shadow-2xl backdrop-blur" style="animation:art-pop .7s cubic-bezier(.34,1.56,.64,1) 1s both" data-depth="28">' +
            '<span class="grid size-9 place-items-center rounded-full bg-accent text-white">' + Nava.icons.svg('bag', 'size-4') + '</span>' +
            '<div><p class="text-sm font-semibold">سفارش جدید #۸۴۲۲</p><p class="text-[11px] text-white/50">همین حالا · ۴٫۸ میلیون تومان</p></div>' +
          '</div>' +

          '<div class="absolute -bottom-10 -start-8 flex items-center gap-3 rounded-xl border border-white/10 bg-zinc-900/90 p-3 pe-5 shadow-2xl backdrop-blur" style="animation:art-pop .7s cubic-bezier(.34,1.56,.64,1) 1.3s both" data-depth="20">' +
            '<svg viewBox="0 0 36 36" class="size-10 -rotate-90"><circle cx="18" cy="18" r="15" fill="none" stroke="rgb(255 255 255 / .15)" stroke-width="4"/>' +
              '<circle cx="18" cy="18" r="15" fill="none" stroke="hsl(var(--warning))" stroke-width="4" stroke-linecap="round" stroke-dasharray="94.2" stroke-dashoffset="94.2" style="animation:art-ring 1.6s cubic-bezier(.16,1,.3,1) 1.5s forwards"/></svg>' +
            '<div><p class="text-sm font-semibold">۷۶٪ هدف ماهانه</p><p class="text-[11px] text-white/50">۱۲ روز باقی‌مانده</p></div>' +
          '</div>' +
        '</div>' +
      '</div>' +

      // متن پایین
      '<div class="relative z-10 p-10">' +
        '<h2 class="max-w-md text-3xl font-extrabold leading-snug">مدیریت هوشمند فروش،<br><span class="text-accent">همه در یک نگاه.</span></h2>' +
        '<p class="mt-4 max-w-md text-sm leading-7 text-white/60">«از وقتی به نوا مهاجرت کردیم، زمان پردازش سفارش‌ها نصف شد و گزارش‌ها دقیق‌تر از همیشه‌اند.»</p>' +
        '<div class="mt-6 flex items-center gap-3">' +
          '<div class="flex -space-x-2 space-x-reverse">' +
            ['س', 'ع', 'م', 'ر'].map((c, i) => '<span class="grid size-8 place-items-center rounded-full border-2 border-zinc-950 text-xs font-bold ' + ['bg-accent', 'bg-zinc-700', 'bg-warning text-zinc-900', 'bg-zinc-500'][i] + '">' + c + '</span>').join('') +
          '</div>' +
          '<p class="text-xs text-white/60"><b class="text-white">+۲٬۴۰۰</b> فروشگاه به نوا اعتماد کرده‌اند</p>' +
        '</div>' +
      '</div>';

    effects.countUp($('[data-art-count]', art), 48.2, { decimals: 1, duration: 2200 });

    // پارالاکس کارت‌ها با حرکت ماوس
    if (prefersReducedMotion()) return;
    const layers = $$('[data-depth]', art);
    art.addEventListener('pointermove', (e) => {
      const r = art.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      layers.forEach((l) => { l.style.translate = (x * -l.dataset.depth) + 'px ' + (y * -l.dataset.depth) + 'px'; });
    });
    art.addEventListener('pointerleave', () => layers.forEach((l) => { l.style.translate = ''; }));
  }

  /* ------------------------------------------------------------------
     ورود و ثبت‌نام
     ------------------------------------------------------------------ */
  function initSignForm() {
    const form = $('[data-auth-form]');
    if (!form) return;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!forms.validate(form)) return;
      const btn = $('[type="submit"]', form);
      forms.loading(btn, true);
      await wait(1400);
      btn.innerHTML = Nava.icons.svg('check', 'size-4') + (page === 'login' ? 'خوش آمدید!' : 'حساب ساخته شد!');
      Nava.toast(page === 'login' ? 'ورود موفق — در حال انتقال به داشبورد' : 'حساب شما ساخته شد — در حال انتقال');
      await wait(900);
      location.href = 'index.html';
    });
  }

  /* ------------------------------------------------------------------
     بازیابی رمز (چندمرحله‌ای)
     ------------------------------------------------------------------ */
  function initForgot() {
    if (page !== 'forgot') return;
    const steps = $$('[data-step]');
    const bars = $$('[data-steps] li');
    let timer;

    const go = (n) => {
      steps.forEach((s) => { s.hidden = +s.dataset.step !== n; });
      bars.forEach((b, i) => b.classList.toggle('bg-primary', i < n));
      bars.forEach((b, i) => b.classList.toggle('bg-muted', i >= n));
      $('[data-steps]').hidden = n === 4;
      $('[data-footer-link]').hidden = n === 4;
      const focus = $('[data-step="' + n + '"] input');
      focus && setTimeout(() => focus.focus(), 50);
    };

    const startTimer = () => {
      const btn = $('[data-resend]');
      let t = 59;
      btn.disabled = true;
      clearInterval(timer);
      $('[data-timer]').textContent = '۰:' + fa(t);
      timer = setInterval(() => {
        t--;
        $('[data-timer]').textContent = '۰:' + (t < 10 ? '۰' : '') + fa(t);
        if (t <= 0) { clearInterval(timer); btn.disabled = false; btn.textContent = 'ارسال مجدد'; }
      }, 1000);
    };

    const emailForm = $('[data-form="email"]');
    emailForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!forms.validate(emailForm)) return;
      const btn = $('[type="submit"]', emailForm);
      forms.loading(btn, true);
      await wait(1100);
      forms.loading(btn, false);
      $('[data-email-echo]').textContent = $('#email').value.trim();
      Nava.toast('کد تأیید ارسال شد');
      go(2);
      startTimer();
    });

    const code = forms.otp($('[data-otp]'), async () => {
      $$('[data-otp] input').forEach((c) => (c.disabled = true));
      await wait(800);
      $$('[data-otp] input').forEach((c) => (c.disabled = false));
      Nava.toast('کد تأیید شد');
      go(3);
    });

    $('[data-resend]').addEventListener('click', () => { Nava.toast('کد جدید ارسال شد', { type: 'info' }); code.reset(); startTimer(); });
    $('[data-back]').addEventListener('click', () => { clearInterval(timer); go(1); });

    const pwForm = $('[data-form="password"]');
    pwForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!forms.validate(pwForm)) return;
      const btn = $('[type="submit"]', pwForm);
      forms.loading(btn, true);
      await wait(1200);
      forms.loading(btn, false);
      go(4);
    });
  }

  renderArt();
  initSignForm();
  initForgot();
})(window.Nava);
