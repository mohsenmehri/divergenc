/**
 * صفحه‌ی تحلیل‌ها: شاخص‌ها، نمودار ترافیک، نقشه‌ی حرارتی، دستگاه‌ها، قیف و شهرها
 */
(function (Nava) {
  'use strict';
  const { $, $$, fa, faDigits, escape } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const { charts, effects, ui } = Nava;

  /* ---------- داده‌ها ---------- */
  const wave = (n, base, amp, trend) => Array.from({ length: n }, (_, i) => Math.round(base + Math.sin(i / 1.7) * amp + Math.cos(i / 3.1) * amp * .6 + i * trend));
  const RANGES = {
    week: { labels: ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'], visits: wave(7, 42, 8, 2), orders: wave(7, 18, 4, 1) },
    month: { labels: Array.from({ length: 30 }, (_, i) => faDigits(i + 1) + ' مهر'), visits: wave(30, 38, 9, 1.1), orders: wave(30, 15, 4, .5) },
    year: { labels: ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'], visits: wave(12, 820, 140, 40), orders: wave(12, 320, 60, 18) },
  };
  const KPIS = {
    week: [12.8, 4.2, 3.4, 4.1], month: [48.6, 16.9, 3.62, 4.6], year: [612, 188, 3.9, 4.3],
  };
  const KPI_META = [
    { title: 'بازدید صفحات', unit: 'هزار بازدید', icon: 'eye', trend: 14.2, color: 'chart-1', dec: 1 },
    { title: 'کاربران یکتا', unit: 'هزار کاربر', icon: 'users', trend: 9.8, color: 'chart-2', dec: 1 },
    { title: 'نرخ تبدیل', unit: 'درصد', icon: 'percent', trend: -0.6, color: 'chart-4', dec: 2, suffix: '٪' },
    { title: 'مدت جلسه', unit: 'دقیقه به‌طور میانگین', icon: 'clock', trend: 4.1, color: 'chart-5', dec: 1 },
  ];

  /* ---------- شاخص‌ها ---------- */
  function renderKpis(range) {
    const root = $('[data-kpis]');
    const first = !root.children.length;
    if (first) {
      root.innerHTML = KPI_META.map((k, i) =>
        '<article class="card card-hover reveal p-5" style="--delay:' + i * 80 + 'ms">' +
          '<div class="flex items-center justify-between"><p class="text-sm text-muted-foreground">' + k.title + '</p>' +
          '<span class="grid size-9 place-items-center rounded-lg" style="background:hsl(var(--' + k.color + ') / .12);color:hsl(var(--' + k.color + '))">' + icon(k.icon, 'size-4') + '</span></div>' +
          '<p class="mt-3 text-3xl font-extrabold tracking-tight tabular" data-v>۰</p>' +
          '<div class="mt-2 flex items-center justify-between text-xs"><span class="text-muted-foreground">' + k.unit + '</span>' +
          '<span class="badge ' + (k.trend >= 0 ? 'badge-primary' : 'badge-danger') + '">' + icon(k.trend >= 0 ? 'arrow-up' : 'arrow-down', 'size-3') + fa(Math.abs(k.trend), 1) + '٪</span></div>' +
        '</article>'
      ).join('');
    }
    $$('[data-v]', root).forEach((el, i) => {
      const go = () => effects.countUp(el, KPIS[range][i], { decimals: KPI_META[i].dec, suffix: KPI_META[i].suffix || '', duration: first ? 1600 : 800 });
      first ? effects.onVisible(el, go) : go();
    });
  }

  /* ---------- ترافیک ---------- */
  const cfg = (r) => ({
    labels: RANGES[r].labels,
    series: [
      { name: 'بازدید', color: 'chart-1', values: RANGES[r].visits },
      { name: 'سفارش', color: 'chart-2', values: RANGES[r].orders },
    ],
  });
  const trafficHost = $('[data-chart="traffic"]');
  const traffic = charts.areaChart(trafficHost, cfg('month'));
  effects.onVisible(trafficHost, traffic.play);

  ui.segmented($('[data-range]'), (r) => { traffic.update(cfg(r)); renderKpis(r); });
  renderKpis('month');

  /* ---------- نقشه‌ی حرارتی ---------- */
  function heatmap() {
    const days = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
    const hours = Array.from({ length: 24 }, (_, h) => h);
    const value = (d, h) => {
      const peak = Math.exp(-Math.pow(h - 21, 2) / 10) + Math.exp(-Math.pow(h - 13, 2) / 6) * .7;
      return Math.round((peak * (d >= 5 ? 1.3 : 1) + ((d * 7 + h * 3) % 5) / 20) * 60);
    };
    const max = 90;
    const root = $('[data-heatmap]');
    root.innerHTML =
      '<div class="grid grid-cols-[4.5rem_repeat(24,minmax(0,1fr))] gap-1 text-[10px] text-muted-foreground">' +
        '<span></span>' + hours.map((h) => '<span class="text-center">' + (h % 3 === 0 ? fa(h) : '') + '</span>').join('') +
        days.map((d, di) =>
          '<span class="flex items-center text-[11px]">' + d + '</span>' +
          hours.map((h) => {
            const v = value(di, h);
            const a = Math.max(.06, Math.min(1, v / max));
            return '<span class="aspect-square rounded-[4px] transition-transform duration-200 hover:z-10 hover:scale-150 hover:ring-2 hover:ring-background" style="background:hsl(var(--accent) / ' + a.toFixed(2) + ');opacity:0;animation:fade-in .5s ease ' + ((di * 24 + h) * 6) + 'ms forwards" title="' + d + '، ساعت ' + fa(h) + ': ' + fa(v) + ' سفارش"></span>';
          }).join('')
        ).join('') +
      '</div>';
  }
  effects.onVisible($('[data-heatmap]'), heatmap);

  /* ---------- دستگاه‌ها ---------- */
  const DEVICES = [
    { label: 'موبایل', value: 6820, color: 'chart-2', icon: 'smartphone' },
    { label: 'دسکتاپ', value: 3410, color: 'chart-1', icon: 'monitor' },
    { label: 'تبلت', value: 1170, color: 'chart-4', icon: 'tablet' },
  ];
  const devTotal = DEVICES.reduce((a, d) => a + d.value, 0);
  const legend = $('[data-devices-legend]');
  legend.innerHTML = DEVICES.map((d) =>
    '<li class="rounded-lg p-2 transition-colors"><span class="mx-auto grid size-8 place-items-center rounded-lg" style="background:hsl(var(--' + d.color + ') / .12);color:hsl(var(--' + d.color + '))">' + icon(d.icon, 'size-4') + '</span>' +
    '<p class="mt-1.5 text-muted-foreground">' + d.label + '</p><p class="font-bold">' + fa(Math.round(d.value / devTotal * 100)) + '٪</p></li>'
  ).join('');
  const items = $$('li', legend);
  const donut = charts.donutChart($('[data-chart="devices"]'), {
    segments: DEVICES, centerLabel: 'نشست',
    onHover: (i) => items.forEach((li, j) => li.classList.toggle('bg-muted', i === j)),
  });
  items.forEach((li, i) => { li.addEventListener('pointerenter', () => donut.highlight(i)); li.addEventListener('pointerleave', () => donut.highlight(-1)); });
  effects.onVisible($('[data-chart="devices"]'), donut.play);

  /* ---------- قیف فروش ---------- */
  const FUNNEL = [
    { label: 'بازدید از فروشگاه', value: 48600, icon: 'eye' },
    { label: 'مشاهده‌ی محصول', value: 21300, icon: 'package' },
    { label: 'افزودن به سبد', value: 6420, icon: 'bag' },
    { label: 'شروع پرداخت', value: 2310, icon: 'card' },
    { label: 'خرید موفق', value: 1760, icon: 'check-circle' },
  ];
  const funnel = $('[data-funnel]');
  funnel.innerHTML = FUNNEL.map((f, i) => {
    const pct = f.value / FUNNEL[0].value * 100;
    const drop = i ? Math.round((1 - f.value / FUNNEL[i - 1].value) * 100) : 0;
    return '<li>' +
      '<div class="mb-1.5 flex items-center justify-between text-sm"><span class="flex items-center gap-2">' + icon(f.icon, 'size-4 text-muted-foreground') + f.label + '</span>' +
      '<span class="font-semibold tabular">' + fa(f.value) + '</span></div>' +
      '<div class="h-7 overflow-hidden rounded-md bg-muted"><span class="flex h-full items-center rounded-md px-2 text-[11px] font-medium ' + (i === FUNNEL.length - 1 ? 'bg-accent text-white' : 'bg-foreground/80 text-background') + '" data-w="' + Math.max(pct, 8) + '" style="width:0;transition:width 1.2s cubic-bezier(.16,1,.3,1) ' + i * 120 + 'ms">' + fa(pct, pct < 10 ? 1 : 0) + '٪</span></div>' +
      (drop ? '<p class="mt-1 text-[11px] text-muted-foreground">ریزش ' + fa(drop) + '٪ نسبت به مرحله قبل</p>' : '') +
    '</li>';
  }).join('');
  effects.onVisible(funnel, () => $$('[data-w]', funnel).forEach((b) => (b.style.width = b.dataset.w + '%')));

  /* ---------- دسته‌ها ---------- */
  const catHost = $('[data-chart="categories"]');
  const cats = charts.barChart(catHost, { labels: ['صوتی', 'موبایل', 'پوشیدنی', 'کامپیوتر', 'دوربین', 'جانبی'], values: [412, 688, 356, 290, 245, 128], unit: 'میلیون تومان' });
  effects.onVisible(catHost, cats.play);

  /* ---------- شهرها ---------- */
  const CITIES = [['تهران', 38], ['اصفهان', 14], ['مشهد', 11], ['شیراز', 9], ['تبریز', 7], ['کرج', 6]];
  const cityRoot = $('[data-cities]');
  cityRoot.innerHTML = CITIES.map(([c, p], i) =>
    '<li><div class="mb-1.5 flex items-center justify-between text-sm"><span class="flex items-center gap-2"><span class="grid size-6 place-items-center rounded-md bg-muted text-[11px] font-bold">' + fa(i + 1) + '</span>' + escape(c) + '</span>' +
    '<span class="font-semibold tabular">' + fa(p) + '٪</span></div>' +
    '<div class="progress h-1.5"><span class="' + (i === 0 ? 'bg-accent' : 'bg-foreground/60') + '" data-w="' + (p / 38 * 100) + '"></span></div></li>'
  ).join('');
  effects.onVisible(cityRoot, () => $$('[data-w]', cityRoot).forEach((b, i) => setTimeout(() => (b.style.width = b.dataset.w + '%'), i * 100)));

  effects.reveal();
})(window.Nava);
