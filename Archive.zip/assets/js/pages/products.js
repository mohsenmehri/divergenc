/**
 * صفحه‌ی محصولات: نمای شبکه‌ای/فهرستی، فیلتر دسته، افزودن، ویرایش و حذف
 */
(function (Nava) {
  'use strict';
  const { $, $$, fa, escape } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const { ui, forms, effects } = Nava;
  const { render } = ui;
  const D = Nava.data;
  const products = D.products;
  const CATS = Array.from(new Set(products.map((p) => p.category)));
  const LOW = 10;

  /* ---------- آمار ---------- */
  function renderStats() {
    render.stats($('[data-stats]'), [
      { label: 'کل محصولات', value: products.length, icon: 'package', tone: 'primary' },
      { label: 'فعال در فروشگاه', value: products.filter((p) => p.status === 'active').length, icon: 'check-circle', tone: 'info' },
      { label: 'موجودی کم', value: products.filter((p) => p.stock > 0 && p.stock < LOW).length, icon: 'alert', tone: 'warning' },
      { label: 'ناموجود', value: products.filter((p) => p.stock === 0).length, icon: 'x-circle', tone: 'danger' },
    ]);
  }

  /* ---------- قطعات نمایشی ---------- */
  const stars = (r) => '<span class="flex items-center gap-0.5 text-warning">' + icon('star', 'size-3.5 fill-current') + '<b class="text-xs text-foreground">' + fa(r, 1) + '</b></span>';
  const stockBar = (p) => {
    const pct = Math.min(100, (p.stock / 150) * 100);
    const color = p.stock === 0 ? 'bg-danger' : p.stock < LOW ? 'bg-warning' : 'bg-foreground/70';
    return '<div class="flex items-center gap-2"><div class="progress h-1.5 flex-1"><span class="' + color + '" style="width:' + pct + '%"></span></div>' +
      '<span class="text-[11px] tabular ' + (p.stock < LOW ? 'font-semibold text-danger' : 'text-muted-foreground') + '">' + (p.stock ? fa(p.stock) + ' عدد' : 'ناموجود') + '</span></div>';
  };
  const statusBadge = (p) => '<span class="badge ' + D.productStatus[p.status].cls + '">' + D.productStatus[p.status].label + '</span>';
  const thumb = (p, size) => p.image
    ? '<img src="' + p.image + '" alt="" class="' + size + ' object-cover">'
    : '<span class="grid ' + size + ' place-items-center ' + D.tone[p.color] + '">' + icon(p.icon, 'size-1/3 max-w-12') + '</span>';
  const actions = (p) =>
    '<button type="button" class="btn-icon size-8" data-edit="' + p.id + '" aria-label="ویرایش">' + icon('edit', 'size-4') + '</button>' +
    '<button type="button" class="btn-icon size-8 hover:!bg-danger/10 hover:!text-danger" data-delete="' + p.id + '" aria-label="حذف">' + icon('trash', 'size-4') + '</button>';

  const table = Nava.dataTable({
    rows: products,
    pageSize: 8,
    searchKeys: ['name', 'sku', 'category'],
    head: $('[data-head]'),
    tbody: $('[data-tbody]'),
    list: $('[data-grid]'),
    empty: $('[data-empty]'),
    pager: $('[data-pager]'),
    info: $('[data-info]'),
    scrollTarget: $('[data-table-card]'),
    card: (p, i) =>
      '<li class="card card-hover group overflow-hidden" style="animation:fade-up .55s cubic-bezier(.16,1,.3,1) ' + i * 50 + 'ms both">' +
        '<div class="relative aspect-[4/3] overflow-hidden border-b">' +
          '<div class="size-full transition-transform duration-700 ease-out-expo group-hover:scale-110">' + thumb(p, 'size-full') + '</div>' +
          '<div class="absolute start-3 top-3">' + statusBadge(p) + '</div>' +
          '<div class="absolute end-3 top-3 flex translate-y-[-120%] gap-1 rounded-lg bg-card/90 p-1 shadow-elevation-2 backdrop-blur transition-transform duration-500 ease-spring group-hover:translate-y-0 group-focus-within:translate-y-0">' + actions(p) + '</div>' +
        '</div>' +
        '<div class="space-y-3 p-4">' +
          '<div class="flex items-start justify-between gap-2"><div class="min-w-0"><p class="truncate font-semibold">' + escape(p.name) + '</p>' +
          '<p class="mt-0.5 text-xs text-muted-foreground">' + escape(p.category) + ' · ' + p.sku + '</p></div>' + stars(p.rating) + '</div>' +
          stockBar(p) +
          '<div class="flex items-center justify-between border-t pt-3"><p class="font-extrabold tabular">' + render.money(p.price) + '</p>' +
          '<p class="text-xs text-muted-foreground">' + fa(p.sold) + ' فروش</p></div>' +
        '</div>' +
      '</li>',
    row: (p, i) =>
      '<tr style="animation:fade-up .45s cubic-bezier(.16,1,.3,1) ' + i * 35 + 'ms both">' +
        '<td><div class="flex items-center gap-3"><span class="size-11 overflow-hidden rounded-lg">' + thumb(p, 'size-full') + '</span>' +
        '<div><p class="font-medium">' + escape(p.name) + '</p><p class="text-xs text-muted-foreground">' + p.sku + '</p></div></div></td>' +
        '<td class="text-muted-foreground">' + escape(p.category) + '</td>' +
        '<td class="font-semibold tabular">' + render.money(p.price) + '</td>' +
        '<td class="min-w-40">' + stockBar(p) + '</td>' +
        '<td class="tabular">' + fa(p.sold) + '</td>' +
        '<td>' + statusBadge(p) + '</td>' +
        '<td><div class="flex justify-end gap-1">' + actions(p) + '</div></td>' +
      '</tr>',
  });

  $('[data-search]').addEventListener('input', Nava.utils.debounce((e) => table.search(e.target.value), 150));

  /* ---------- دسته‌ها ---------- */
  $('[data-chips]').innerHTML = ['همه'].concat(CATS).map((c, i) =>
    '<button type="button" class="chip" data-value="' + c + '" aria-pressed="' + (i === 0) + '">' + c + '</button>').join('');
  ui.chips($('[data-chips]'), (c) => table.filter(c === 'همه' ? null : (p) => p.category === c));

  /* ---------- نوع نمایش ---------- */
  ui.segmented($('[data-view-toggle]'), (v) => {
    $('[data-grid]').classList.toggle('hidden', v !== 'grid');
    $('[data-list-wrap]').classList.toggle('hidden', v !== 'list');
    table.refresh();
  });

  /* ---------- افزودن / ویرایش ---------- */
  const modal = ui.overlay('product-modal');
  const form = $('[data-product-form]');
  const preview = $('[data-preview]');
  let editing = null;
  let image = null;
  $('[data-categories]').innerHTML = CATS.map((c) => '<option>' + c + '</option>').join('');

  function setPreview(src) {
    image = src;
    preview.classList.toggle('hidden', !src);
    $('[data-drop-hint]').classList.toggle('hidden', !!src);
    if (src) preview.src = src;
  }
  function readFile(file) {
    if (!file || !file.type.startsWith('image/')) return;
    const r = new FileReader();
    r.onload = () => setPreview(r.result);
    r.readAsDataURL(file);
  }
  const zone = $('[data-dropzone]');
  $('[data-file]').addEventListener('change', (e) => readFile(e.target.files[0]));
  ['dragenter', 'dragover'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.add('is-over'); }));
  ['dragleave', 'drop'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.remove('is-over'); }));
  zone.addEventListener('drop', (e) => readFile(e.dataTransfer.files[0]));

  function openForm(p) {
    editing = p || null;
    form.reset();
    $$('.field', form).forEach((f) => f.classList.remove('has-error'));
    $('[data-modal-title]').textContent = p ? 'ویرایش محصول' : 'افزودن محصول';
    if (p) {
      $('#p-name').value = p.name;
      $('#p-cat').value = p.category;
      $('#p-stock').value = p.stock;
      $('#p-price').value = p.price;
      $('[data-publish]').checked = p.status !== 'draft';
    }
    setPreview(p ? p.image : null);
    modal.open();
  }
  $('[data-new-product]').addEventListener('click', () => openForm());
  if (location.hash === '#new') setTimeout(() => openForm(), 400);

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!forms.validate(form)) return;
    const stock = Math.max(0, +$('#p-stock').value);
    const values = {
      name: $('#p-name').value.trim(),
      category: $('#p-cat').value,
      stock,
      price: Math.max(0, +$('#p-price').value),
      image,
      status: stock === 0 ? 'out' : $('[data-publish]').checked ? 'active' : 'draft',
    };
    if (editing) {
      Object.assign(editing, values);
      Nava.toast('«' + values.name + '» به‌روزرسانی شد');
    } else {
      const id = Math.max.apply(null, products.map((p) => p.id)) + 1;
      products.unshift(Object.assign({ id, sku: 'NV-' + (1040 + id * 7), sold: 0, rating: 5, icon: 'package', color: 'primary' }, values));
      Nava.toast('«' + values.name + '» به فروشگاه اضافه شد');
    }
    modal.close();
    table.refresh();
    renderStats();
  });

  /* ---------- حذف ---------- */
  const confirm = ui.overlay('delete-modal');
  let toDelete = null;
  $('[data-confirm-delete]').addEventListener('click', () => {
    table.remove([toDelete]);
    confirm.close();
    renderStats();
    Nava.toast('«' + toDelete.name + '» حذف شد', { type: 'error' });
  });

  document.addEventListener('click', (e) => {
    const ed = e.target.closest('[data-edit]');
    const del = e.target.closest('[data-delete]');
    if (ed) openForm(products.find((p) => p.id === +ed.dataset.edit));
    if (del) {
      toDelete = products.find((p) => p.id === +del.dataset.delete);
      $('[data-delete-name]').textContent = toDelete.name;
      confirm.open();
    }
  });

  renderStats();
  effects.reveal();
})(window.Nava);
