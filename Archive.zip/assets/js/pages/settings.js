/**
 * صفحه‌ی تنظیمات: تب‌ها، فرم‌ها، تیم، طرح‌ها، اعلان‌ها، امنیت و ظاهر
 */
(function (Nava) {
  'use strict';
  const { $, $$, fa, escape } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const { ui, forms, effects } = Nava;
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ---------- تب‌ها (با پشتیبانی از #hash) ---------- */
  const tabs = ui.tabs($('[data-tabs]'), (id) => history.replaceState(null, '', '#' + id));
  window.addEventListener('hashchange', () => tabs.select(location.hash.slice(1)));

  /* ---------- فرم‌های ذخیره‌ی ساده ---------- */
  async function save(form, message) {
    if (!forms.validate(form)) return false;
    const btn = $('[type="submit"]', form);
    forms.loading(btn, true);
    await wait(900);
    forms.loading(btn, false);
    Nava.toast(message);
    return true;
  }
  $('[data-settings-form]').addEventListener('submit', (e) => { e.preventDefault(); save(e.target, 'اطلاعات فروشگاه ذخیره شد'); });
  $('[data-password-form]').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (await save(e.target, 'رمز عبور با موفقیت تغییر کرد')) e.target.reset();
  });
  $('[data-logo-input]').addEventListener('change', (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => { $('[data-settings-form] img').src = r.result; Nava.toast('لوگو به‌روزرسانی شد'); };
    r.readAsDataURL(f);
  });

  /* ---------- تیم ---------- */
  const team = [
    { name: 'مدیر سیستم', email: 'admin@nava.ir', role: 'مالک', you: true },
    { name: 'سارا محمدی', email: 'sara@nava.ir', role: 'مدیر' },
    { name: 'کیان شریفی', email: 'kian@nava.ir', role: 'ویرایشگر' },
    { name: 'پریا اکبری', email: 'parya@nava.ir', role: 'پشتیبان', pending: true },
  ];
  const ROLES = ['مدیر', 'ویرایشگر', 'پشتیبان'];
  function renderTeam() {
    $('[data-team]').innerHTML = team.map((m, i) =>
      '<li class="flex flex-wrap items-center gap-3 p-4" style="animation:fade-up .4s cubic-bezier(.16,1,.3,1) ' + i * 50 + 'ms both">' +
        ui.render.avatar(m.name, 'size-10 text-sm') +
        '<div class="min-w-0 flex-1"><p class="flex items-center gap-2 font-medium">' + escape(m.name) + (m.you ? '<span class="badge badge-muted">شما</span>' : '') + (m.pending ? '<span class="badge badge-warning">در انتظار پذیرش</span>' : '') + '</p>' +
        '<p class="truncate text-xs text-muted-foreground" dir="ltr">' + m.email + '</p></div>' +
        (m.you ? '<span class="badge badge-accent">' + m.role + '</span>'
          : '<select class="input h-9 w-32" data-role="' + i + '" aria-label="نقش">' + ROLES.map((r) => '<option' + (r === m.role ? ' selected' : '') + '>' + r + '</option>').join('') + '</select>' +
            '<button type="button" class="btn-icon size-9 hover:!bg-danger/10 hover:!text-danger" data-remove="' + i + '" aria-label="حذف عضو">' + icon('trash', 'size-4') + '</button>') +
      '</li>'
    ).join('');
  }
  renderTeam();
  $('[data-team]').addEventListener('change', (e) => {
    const s = e.target.closest('[data-role]');
    if (s) { team[+s.dataset.role].role = s.value; Nava.toast('نقش ' + team[+s.dataset.role].name + ' به «' + s.value + '» تغییر کرد'); }
  });
  $('[data-team]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-remove]');
    if (!b) return;
    const [m] = team.splice(+b.dataset.remove, 1);
    renderTeam();
    Nava.toast(m.name + ' از تیم حذف شد', { type: 'error' });
  });
  $('[data-invite-form]').addEventListener('submit', (e) => {
    e.preventDefault();
    if (!forms.validate(e.target)) return;
    const email = $('#i-email').value.trim();
    team.push({ name: email.split('@')[0], email, role: $('[data-invite-role]').value, pending: true });
    renderTeam();
    e.target.reset();
    Nava.toast('دعوت‌نامه برای ' + email + ' ارسال شد');
  });

  /* ---------- طرح‌ها ---------- */
  const PLANS = [
    { name: 'پایه', price: 190, desc: 'برای شروع فروش آنلاین', features: ['۵۰۰ سفارش در ماه', '۱ کاربر', 'گزارش‌های پایه', 'پشتیبانی ایمیلی'] },
    { name: 'رشد', price: 490, desc: 'برای کسب‌وکارهای در حال رشد', features: ['۵٬۰۰۰ سفارش در ماه', '۵ کاربر', 'تحلیل‌های پیشرفته', 'پشتیبانی تلفنی'], current: true },
    { name: 'سازمانی', price: 1290, desc: 'برای فروشگاه‌های بزرگ', features: ['سفارش نامحدود', 'کاربر نامحدود', 'API و وب‌هوک', 'مدیر حساب اختصاصی'] },
  ];
  function renderPlans(yearly) {
    $('[data-plans]').innerHTML = PLANS.map((p, i) => {
      const price = yearly ? p.price * 10 : p.price;
      return '<article class="card card-hover relative flex flex-col p-6 ' + (p.current ? 'ring-2 ring-accent' : '') + '" style="animation:fade-up .5s cubic-bezier(.16,1,.3,1) ' + i * 80 + 'ms both">' +
        (p.current ? '<span class="badge badge-accent absolute end-4 top-4">طرح فعلی</span>' : '') +
        '<h3 class="text-lg font-bold">' + p.name + '</h3><p class="mt-1 text-sm text-muted-foreground">' + p.desc + '</p>' +
        '<p class="mt-5 flex items-baseline gap-1"><span class="text-3xl font-extrabold tabular">' + fa(price) + '</span><span class="text-sm text-muted-foreground">هزار تومان / ' + (yearly ? 'سال' : 'ماه') + '</span></p>' +
        '<ul class="my-6 space-y-2.5 text-sm">' + p.features.map((f) => '<li class="flex items-center gap-2">' + icon('check', 'size-4 text-accent') + f + '</li>').join('') + '</ul>' +
        '<button type="button" class="btn mt-auto ' + (p.current ? 'btn-outline' : 'btn-primary') + '" data-plan="' + p.name + '"' + (p.current ? ' disabled' : '') + '>' + (p.current ? 'طرح فعال شما' : 'انتخاب طرح ' + p.name) + '</button>' +
      '</article>';
    }).join('');
  }
  renderPlans(false);
  $('[data-yearly]').addEventListener('change', (e) => renderPlans(e.target.checked));
  $('[data-plans]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-plan]');
    if (b) Nava.toast('درخواست تغییر به طرح «' + b.dataset.plan + '» ثبت شد');
  });
  $('[data-scroll-plans]').addEventListener('click', () => $('[data-plans]').scrollIntoView({ behavior: 'smooth', block: 'center' }));

  const INVOICES = [['INV-۱۰۴۲', '۲۲ مهر ۱۴۰۵'], ['INV-۱۰۲۸', '۲۲ شهریور ۱۴۰۵'], ['INV-۱۰۱۳', '۲۲ مرداد ۱۴۰۵'], ['INV-۰۹۹۷', '۲۲ تیر ۱۴۰۵']];
  $('[data-invoices]').innerHTML = INVOICES.map(([n, d]) =>
    '<tr><td class="font-medium tabular" dir="ltr">' + n + '</td><td class="text-muted-foreground">' + d + '</td><td>رشد</td><td class="tabular">' + ui.render.money(490000) + '</td>' +
    '<td><span class="badge badge-primary badge-dot">پرداخت‌شده</span></td>' +
    '<td class="text-end"><button type="button" class="btn btn-ghost h-8 px-3 text-xs" data-invoice="' + n + '">' + icon('download', 'size-4') + 'دانلود</button></td></tr>'
  ).join('');
  $('[data-invoices]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-invoice]');
    if (!b) return;
    ui.downloadCSV(b.dataset.invoice + '.csv', [['شماره', 'طرح', 'مبلغ (تومان)', 'وضعیت'], [b.dataset.invoice, 'رشد', 490000, 'پرداخت‌شده']]);
    Nava.toast('صورتحساب ' + b.dataset.invoice + ' دانلود شد');
  });

  /* ---------- اعلان‌ها ---------- */
  const NOTIFS = [
    ['bag', 'سفارش جدید', 'هنگام ثبت هر سفارش جدید', [true, true, false]],
    ['package', 'موجودی کم', 'وقتی موجودی کالا کمتر از ۱۰ شود', [true, false, true]],
    ['message', 'پیام مشتری', 'دریافت پیام یا تیکت جدید', [true, true, true]],
    ['file', 'گزارش هفتگی', 'خلاصه‌ی عملکرد هر شنبه صبح', [false, true, false]],
    ['shield', 'هشدارهای امنیتی', 'ورود از دستگاه یا مکان جدید', [true, true, true]],
  ];
  $('[data-notif-settings]').innerHTML =
    '<div class="hidden grid-cols-[1fr_repeat(3,4.5rem)] items-center gap-2 px-5 py-3 text-xs text-muted-foreground sm:grid"><span></span><span class="text-center">داخل پنل</span><span class="text-center">ایمیل</span><span class="text-center">پیامک</span></div>' +
    NOTIFS.map(([ic, t, d, ch]) =>
      '<div class="grid grid-cols-[1fr_auto] items-center gap-3 p-5 sm:grid-cols-[1fr_repeat(3,4.5rem)]">' +
        '<div class="flex items-center gap-3"><span class="grid size-9 shrink-0 place-items-center rounded-lg bg-muted">' + icon(ic, 'size-4') + '</span><div><p class="text-sm font-medium">' + t + '</p><p class="text-xs text-muted-foreground">' + d + '</p></div></div>' +
        '<div class="flex gap-4 sm:contents">' + ch.map((on, j) => '<label class="flex flex-col items-center gap-1 sm:block sm:text-center"><input type="checkbox" class="switch" data-notif' + (on ? ' checked' : '') + ' aria-label="' + t + ' — ' + ['پنل', 'ایمیل', 'پیامک'][j] + '"><span class="text-[10px] text-muted-foreground sm:hidden">' + ['پنل', 'ایمیل', 'پیامک'][j] + '</span></label>').join('') + '</div>' +
      '</div>'
    ).join('');
  $('[data-notif-settings]').addEventListener('change', Nava.utils.debounce(() => Nava.toast('ترجیحات اعلان ذخیره شد'), 500));

  /* ---------- امنیت ---------- */
  $('[data-2fa]').addEventListener('change', (e) => Nava.toast(e.target.checked ? 'احراز هویت دومرحله‌ای فعال شد' : 'احراز هویت دومرحله‌ای غیرفعال شد', { type: e.target.checked ? 'success' : 'info' }));
  const sessions = [
    { device: 'مک‌بوک پرو · کروم', place: 'تهران، ایران', time: 'همین حالا', icon: 'monitor', current: true },
    { device: 'آیفون ۱۵ · سافاری', place: 'تهران، ایران', time: '۲ ساعت پیش', icon: 'smartphone' },
    { device: 'ویندوز · فایرفاکس', place: 'اصفهان، ایران', time: '۳ روز پیش', icon: 'monitor' },
  ];
  function renderSessions() {
    $('[data-sessions]').innerHTML = sessions.map((s, i) =>
      '<li class="flex items-center gap-3 px-5 py-4"><span class="grid size-10 place-items-center rounded-lg bg-muted">' + icon(s.icon, 'size-5') + '</span>' +
      '<div class="flex-1"><p class="flex items-center gap-2 text-sm font-medium">' + s.device + (s.current ? '<span class="badge badge-accent badge-dot">این دستگاه</span>' : '') + '</p>' +
      '<p class="text-xs text-muted-foreground">' + s.place + ' · ' + s.time + '</p></div>' +
      (s.current ? '' : '<button type="button" class="btn btn-ghost h-8 px-3 text-xs text-danger" data-revoke="' + i + '">خروج</button>') + '</li>'
    ).join('');
  }
  renderSessions();
  $('[data-sessions]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-revoke]');
    if (!b) return;
    sessions.splice(+b.dataset.revoke, 1);
    renderSessions();
    Nava.toast('نشست خاتمه یافت');
  });
  $('[data-revoke-all]').addEventListener('click', () => {
    sessions.splice(0, sessions.length, sessions.find((s) => s.current));
    renderSessions();
    Nava.toast('از همه‌ی دستگاه‌های دیگر خارج شدید');
  });

  /* ---------- ظاهر ---------- */
  const radios = $$('[name="theme"]');
  const syncTheme = () => radios.forEach((r) => { r.checked = r.value === Nava.theme.mode(); });
  syncTheme();
  radios.forEach((r) => r.addEventListener('change', () => { Nava.theme.set(r.value); setTimeout(syncTheme, 50); }));
  document.addEventListener('nava:themechange', () => setTimeout(syncTheme, 50));

  const collapsed = $('[data-collapsed-pref]');
  collapsed.checked = document.documentElement.classList.contains('sidebar-collapsed');
  collapsed.addEventListener('change', () => {
    if (collapsed.checked !== document.documentElement.classList.contains('sidebar-collapsed')) $('[data-collapse-toggle]').click();
  });

  effects.reveal();
})(window.Nava);
