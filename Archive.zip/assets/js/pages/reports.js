/**
 * صفحه‌ی گزارش‌ها: خلاصه‌ی مالی، نمودار سود، ترکیب هزینه‌ها و ساخت/دانلود گزارش
 */
(function (Nava) {
  'use strict';
  const { $, $$, fa, escape } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const { charts, effects, ui, forms } = Nava;
  const D = Nava.data;

  /* ---------- خلاصه ---------- */
  const SUMMARY = [
    { label: 'درآمد ناخالص', value: 18078, unit: 'میلیون تومان', trend: 18.9, icon: 'wallet' },
    { label: 'سود خالص', value: 4212, unit: 'میلیون تومان', trend: 24.1, icon: 'activity' },
    { label: 'مالیات بر ارزش افزوده', value: 1627, unit: 'میلیون تومان', trend: 9.2, icon: 'file' },
    { label: 'مرجوعی‌ها', value: 2.4, dec: 1, suffix: '٪', unit: 'از کل سفارش‌ها', trend: -0.8, icon: 'refresh' },
  ];
  const sum = $('[data-summary]');
  sum.innerHTML = SUMMARY.map((s, i) =>
    '<article class="card card-hover reveal p-5" style="--delay:' + i * 80 + 'ms">' +
      '<div class="flex items-center justify-between"><span class="grid size-10 place-items-center rounded-xl ' + (i === 1 ? 'bg-accent text-white' : 'bg-muted') + '">' + icon(s.icon, 'size-5') + '</span>' +
      '<span class="badge ' + (s.trend >= 0 ? 'badge-primary' : 'badge-danger') + '">' + icon(s.trend >= 0 ? 'arrow-up' : 'arrow-down', 'size-3') + fa(Math.abs(s.trend), 1) + '٪</span></div>' +
      '<p class="mt-4 text-sm text-muted-foreground">' + s.label + '</p>' +
      '<p class="mt-1 text-2xl font-extrabold tabular" data-v="' + i + '">۰</p>' +
      '<p class="text-[11px] text-muted-foreground">' + s.unit + '</p>' +
    '</article>'
  ).join('');
  $$('[data-v]', sum).forEach((el) => {
    const s = SUMMARY[+el.dataset.v];
    effects.onVisible(el, () => effects.countUp(el, s.value, { decimals: s.dec || 0, suffix: s.suffix || '' }));
  });

  /* ---------- سود و زیان ---------- */
  const profitHost = $('[data-chart="profit"]');
  const profit = charts.barChart(profitHost, {
    labels: ['فرو', 'ارد', 'خرد', 'تیر', 'مرد', 'شهر', 'مهر', 'آبا', 'آذر', 'دی', 'بهم', 'اسف'],
    values: [212, 248, 231, 296, 318, 302, 446, 372, 391, 420, 448, 528],
    unit: 'میلیون تومان سود',
  });
  effects.onVisible(profitHost, profit.play);

  /* ---------- ترکیب هزینه‌ها ---------- */
  const COSTS = [['خرید کالا', 58, 'bg-foreground/80'], ['ارسال و لجستیک', 16, 'bg-accent'], ['تبلیغات', 12, 'bg-warning'], ['حقوق و دستمزد', 10, 'bg-foreground/40'], ['سایر', 4, 'bg-foreground/20']];
  const costs = $('[data-costs]');
  costs.innerHTML =
    '<li class="flex h-3 overflow-hidden rounded-full bg-muted">' + COSTS.map(([, p, c], i) => '<span class="' + c + ' h-full" style="width:0;transition:width 1.2s cubic-bezier(.16,1,.3,1) ' + i * 100 + 'ms" data-w="' + p + '"></span>').join('') + '</li>' +
    COSTS.map(([l, p, c]) => '<li class="flex items-center gap-3 text-sm"><span class="size-3 rounded ' + c + '"></span><span class="flex-1">' + l + '</span><b class="tabular">' + fa(p) + '٪</b></li>').join('');
  effects.onVisible(costs, () => $$('[data-w]', costs).forEach((b) => (b.style.width = b.dataset.w + '%')));

  /* ---------- فهرست گزارش‌ها ---------- */
  const reports = [
    { name: 'صورت سود و زیان شهریور', type: 'مالی', date: '۱ مهر ۱۴۰۵', size: '۲۴۸ کیلوبایت', ready: true },
    { name: 'فروش محصولات — فصل تابستان', type: 'فروش', date: '۳۰ شهریور ۱۴۰۵', size: '۱٫۲ مگابایت', ready: true },
    { name: 'موجودی انبار و کالاهای کم‌موجود', type: 'انبار', date: '۲۸ شهریور ۱۴۰۵', size: '۸۶ کیلوبایت', ready: true },
    { name: 'گزارش مالیات بر ارزش افزوده', type: 'مالی', date: '۱۵ شهریور ۱۴۰۵', size: '۱۳۲ کیلوبایت', ready: true },
    { name: 'تحلیل مشتریان ویژه', type: 'فروش', date: '۲ شهریور ۱۴۰۵', size: '۴۱۰ کیلوبایت', ready: true },
  ];
  const TYPE_ICON = { 'مالی': 'wallet', 'فروش': 'bag', 'انبار': 'package' };
  let filter = 'all';
  const list = $('[data-reports]');

  function renderReports(animate) {
    const rows = reports.filter((r) => filter === 'all' || r.type === filter);
    list.innerHTML = rows.map((r, i) =>
      '<li class="flex flex-wrap items-center gap-4 px-5 py-4 transition-colors hover:bg-muted/40"' + (animate === false ? '' : ' style="animation:fade-up .45s cubic-bezier(.16,1,.3,1) ' + i * 50 + 'ms both"') + '>' +
        '<span class="grid size-11 place-items-center rounded-xl bg-muted">' + icon(TYPE_ICON[r.type], 'size-5') + '</span>' +
        '<div class="min-w-0 flex-1"><p class="truncate font-medium">' + escape(r.name) + '</p>' +
        '<p class="mt-0.5 text-xs text-muted-foreground">' + r.type + ' · ' + r.date + (r.ready ? ' · ' + r.size : '') + '</p>' +
        (r.ready ? '' : '<div class="progress mt-2 h-1.5 max-w-xs"><span class="bg-accent" style="width:' + r.progress + '%;transition:width .3s linear"></span></div>') + '</div>' +
        (r.ready
          ? '<span class="badge badge-muted">CSV</span><button type="button" class="btn btn-outline h-9" data-download="' + reports.indexOf(r) + '">' + icon('download', 'size-4') + 'دانلود</button>'
          : '<span class="badge badge-warning"><span class="spinner size-3"></span>در حال ساخت ' + fa(Math.round(r.progress)) + '٪</span>') +
      '</li>'
    ).join('') || '<li class="p-10 text-center text-sm text-muted-foreground">گزارشی در این دسته وجود ندارد.</li>';
  }
  ui.segmented($('[data-report-filter]'), (v) => { filter = v; renderReports(); });
  renderReports();

  list.addEventListener('click', (e) => {
    const b = e.target.closest('[data-download]');
    if (!b) return;
    const r = reports[+b.dataset.download];
    const rows = r.type === 'انبار'
      ? [['کد کالا', 'نام', 'دسته', 'موجودی', 'قیمت']].concat(D.products.map((p) => [p.sku, p.name, p.category, p.stock, p.price]))
      : r.type === 'فروش'
        ? [['شماره', 'مشتری', 'محصول', 'مبلغ', 'وضعیت']].concat(D.orders.map((o) => [o.id, o.customer, o.product, o.amount, D.status[o.status].label]))
        : [['ماه', 'سود خالص (میلیون تومان)']].concat(['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر'].map((m, i) => [m, [212, 248, 231, 296, 318, 302, 446][i]]));
    ui.downloadCSV(r.name + '.csv', rows);
    Nava.toast('«' + r.name + '» دانلود شد');
  });

  /* ---------- ساخت گزارش ---------- */
  const modal = ui.overlay('report-modal');
  const form = $('[data-report-form]');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!forms.validate(form)) return;
    const r = { name: $('#r-name').value.trim(), type: form.type.value, date: '۲۲ مهر ۱۴۰۵', size: '۱۸۴ کیلوبایت', ready: false, progress: 0 };
    reports.unshift(r);
    modal.close();
    form.reset();
    renderReports();
    const t = setInterval(() => {
      r.progress = Math.min(100, r.progress + 7 + Math.random() * 12);
      if (r.progress >= 100) { clearInterval(t); r.ready = true; Nava.toast('گزارش «' + r.name + '» آماده شد'); }
      renderReports(false);
    }, 350);
  });

  effects.reveal();
})(window.Nava);
