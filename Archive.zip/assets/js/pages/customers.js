/**
 * صفحه‌ی مشتریان: بخش‌بندی، فیلتر شهر، مرتب‌سازی و پروفایل کشویی
 */
(function (Nava) {
  'use strict';
  const { $, fa, escape } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const { ui, effects } = Nava;
  const { render } = ui;
  const D = Nava.data;
  const customers = D.customers;

  const total = customers.reduce((a, c) => a + c.spent, 0);
  const totalOrders = customers.reduce((a, c) => a + c.orders, 0);
  render.stats($('[data-stats]'), [
    { label: 'کل مشتریان', value: customers.length, icon: 'users', tone: 'primary' },
    { label: 'مشتریان ویژه', value: customers.filter((c) => c.status === 'vip').length, icon: 'star', tone: 'accent' },
    { label: 'میانگین سفارش', value: Math.round(totalOrders / customers.length), icon: 'bag', tone: 'info' },
    { label: 'میانگین ارزش خرید (میلیون)', value: total / totalOrders / 1e6, decimals: 1, icon: 'wallet', tone: 'warning' },
  ]);

  const badge = (c) => '<span class="badge ' + D.customerStatus[c.status].cls + '">' + (c.status === 'vip' ? icon('star', 'size-3 fill-current') : '') + D.customerStatus[c.status].label + '</span>';

  const table = Nava.dataTable({
    rows: customers,
    pageSize: 8,
    searchKeys: ['name', 'email', 'phone', 'city'],
    head: $('[data-head]'),
    tbody: $('[data-tbody]'),
    list: $('[data-list]'),
    empty: $('[data-empty]'),
    pager: $('[data-pager]'),
    info: $('[data-info]'),
    scrollTarget: $('[data-table-card]'),
    row: (c, i) =>
      '<tr style="animation:fade-up .45s cubic-bezier(.16,1,.3,1) ' + i * 35 + 'ms both">' +
        '<td><div class="flex items-center gap-3">' + render.avatar(c.name) + '<div><p class="font-medium">' + escape(c.name) + '</p><p class="text-xs text-muted-foreground" dir="ltr">' + c.email + '</p></div></div></td>' +
        '<td class="tabular text-muted-foreground" dir="ltr">' + c.phone + '</td>' +
        '<td class="text-muted-foreground">' + c.city + '</td>' +
        '<td class="tabular">' + fa(c.orders) + '</td>' +
        '<td class="font-semibold tabular">' + render.money(c.spent) + '</td>' +
        '<td class="text-muted-foreground">' + c.joined + '</td>' +
        '<td>' + badge(c) + '</td>' +
        '<td class="text-end"><button type="button" class="btn-icon size-8" data-view="' + c.id + '" aria-label="مشاهده پروفایل">' + icon('chevron-left', 'size-4') + '</button></td>' +
      '</tr>',
    card: (c, i) =>
      '<li style="animation:fade-up .45s cubic-bezier(.16,1,.3,1) ' + i * 35 + 'ms both"><button type="button" class="flex w-full items-center gap-3 p-4 text-start" data-view="' + c.id + '">' +
        render.avatar(c.name, 'size-11 text-base') +
        '<div class="min-w-0 flex-1"><div class="flex items-center justify-between gap-2"><p class="truncate font-medium">' + escape(c.name) + '</p>' + badge(c) + '</div>' +
        '<p class="mt-1 text-xs text-muted-foreground">' + c.city + ' · ' + fa(c.orders) + ' سفارش · ' + fa(Math.round(c.spent / 1e6)) + ' میلیون</p></div>' +
      '</button></li>',
  });

  /* ---------- فیلترها ---------- */
  let segment = 'all', city = '';
  const apply = () => table.filter((c) => (segment === 'all' || c.status === segment) && (!city || c.city === city));
  $('[data-chips]').innerHTML = [['all', 'همه']].concat(Object.keys(D.customerStatus).map((k) => [k, D.customerStatus[k].label])).map(([v, l], i) =>
    '<button type="button" class="chip" data-value="' + v + '" aria-pressed="' + (i === 0) + '">' + l + '<span class="chip-count">' + fa(v === 'all' ? customers.length : customers.filter((c) => c.status === v).length) + '</span></button>'
  ).join('');
  ui.chips($('[data-chips]'), (v) => { segment = v; apply(); });
  $('[data-city]').innerHTML = '<option value="">همه شهرها</option>' + D.CITIES.map((c) => '<option>' + c + '</option>').join('');
  $('[data-city]').addEventListener('change', (e) => { city = e.target.value; apply(); });
  $('[data-search]').addEventListener('input', Nava.utils.debounce((e) => table.search(e.target.value), 150));

  $('[data-export]').addEventListener('click', () => {
    ui.downloadCSV('customers.csv', [['نام', 'ایمیل', 'موبایل', 'شهر', 'سفارش‌ها', 'مجموع خرید', 'عضویت', 'وضعیت']].concat(
      table.view.map((c) => [c.name, c.email, c.phone, c.city, c.orders, c.spent, c.joined, D.customerStatus[c.status].label])
    ));
    Nava.toast('فایل CSV دانلود شد');
  });

  /* ---------- پروفایل ---------- */
  const drawer = ui.overlay('customer-drawer');
  function open(c) {
    const recent = D.orders.filter((o) => o.customer === c.name).slice(0, 4);
    $('[data-drawer-body]').innerHTML =
      '<div class="-mt-10 flex items-end justify-between">' +
        '<span class="rounded-full border-4 border-popover">' + render.avatar(c.name, 'size-20 text-2xl') + '</span>' + badge(c) +
      '</div>' +
      '<h2 class="mt-3 text-xl font-bold">' + escape(c.name) + '</h2>' +
      '<p class="text-sm text-muted-foreground">مشتری از ' + c.joined + '</p>' +
      '<div class="mt-5 grid grid-cols-3 gap-2 text-center">' +
        [['سفارش', fa(c.orders)], ['خرید (میلیون)', fa(Math.round(c.spent / 1e6))], ['امتیاز', fa(Math.min(5, 3 + c.orders / 20), 1)]].map(([l, v]) =>
          '<div class="rounded-xl bg-muted/60 p-3"><p class="text-lg font-extrabold tabular">' + v + '</p><p class="text-[11px] text-muted-foreground">' + l + '</p></div>').join('') +
      '</div>' +
      '<dl class="mt-5 space-y-3 text-sm">' +
        [['mail', c.email, 'ltr'], ['phone', c.phone, 'ltr'], ['map-pin', c.city + '، ایران', '']].map(([ic, v, dir]) =>
          '<div class="flex items-center gap-3"><dt class="grid size-8 place-items-center rounded-lg bg-muted text-muted-foreground">' + icon(ic, 'size-4') + '</dt><dd' + (dir ? ' dir="ltr"' : '') + '>' + v + '</dd>' +
          (ic === 'mail' ? '<button type="button" class="btn-icon ms-auto size-8" data-copy-text="' + v + '" aria-label="کپی">' + icon('copy', 'size-4') + '</button>' : '') + '</div>').join('') +
      '</dl>' +
      '<h3 class="mb-3 mt-6 text-sm font-semibold">آخرین سفارش‌ها</h3>' +
      (recent.length ? '<ul class="space-y-2">' + recent.map((o) =>
        '<li class="flex items-center gap-3 rounded-xl border p-3"><span class="grid size-9 place-items-center rounded-lg bg-muted">' + icon(o.productIcon, 'size-4') + '</span>' +
        '<div class="min-w-0 flex-1"><p class="truncate text-sm font-medium">' + escape(o.product) + '</p><p class="text-[11px] text-muted-foreground">' + o.id + ' · ' + o.date + '</p></div>' +
        '<span class="badge ' + D.status[o.status].cls + '">' + D.status[o.status].label + '</span></li>').join('') + '</ul>'
        : '<p class="rounded-xl border border-dashed p-6 text-center text-sm text-muted-foreground">سفارشی در ۳۰ روز اخیر ثبت نشده است.</p>');
    drawer.open();
  }
  document.addEventListener('click', (e) => {
    const v = e.target.closest('[data-view]');
    if (v) open(customers.find((c) => c.id === +v.dataset.view));
    const cp = e.target.closest('[data-copy-text]');
    if (cp) {
      const done = () => Nava.toast('ایمیل کپی شد');
      navigator.clipboard ? navigator.clipboard.writeText(cp.dataset.copyText).then(done, done) : done();
    }
  });

  effects.reveal();
})(window.Nava);
