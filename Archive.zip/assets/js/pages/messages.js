/**
 * صفحه‌ی پیام‌ها: فهرست گفتگوها، رشته‌ی پیام، ارسال و پاسخ شبیه‌سازی‌شده
 */
(function (Nava) {
  'use strict';
  const { $, escape } = Nava.utils;
  const { svg: icon } = Nava.icons;
  const root = $('[data-chat]');
  const convs = Nava.data.conversations;
  const REPLIES = ['ممنون از پاسخ سریعتون 🙏', 'عالیه، منتظرم.', 'باشه، حتماً بررسی می‌کنم.', 'خیلی لطف کردید!', 'متوجه شدم، سپاس.'];
  const EMOJIS = ['😀', '😍', '🙏', '👍', '🎉', '🔥', '❤️', '😅', '🤝', '📦', '✅', '🌹'];
  let active = convs[0];
  let query = '';

  const avatar = (c, size) =>
    '<span class="relative shrink-0">' + Nava.ui.render.avatar(c.name, size || 'size-11 text-sm') +
    (c.online ? '<span class="absolute bottom-0 end-0 size-3 rounded-full border-2 border-card bg-accent"></span>' : '') + '</span>';

  /* ---------- فهرست ---------- */
  function renderList() {
    const rows = convs.filter((c) => !query || c.name.includes(query));
    $('[data-conversations]').innerHTML = rows.map((c, i) => {
      const last = c.messages[c.messages.length - 1];
      const on = c === active;
      return '<li style="animation:fade-up .4s cubic-bezier(.16,1,.3,1) ' + i * 40 + 'ms both"><button type="button" class="flex w-full items-center gap-3 rounded-xl p-3 text-start transition-colors ' + (on ? 'bg-muted' : 'hover:bg-muted/60') + '" data-conv="' + c.id + '">' +
        avatar(c) +
        '<div class="min-w-0 flex-1"><div class="flex items-center justify-between gap-2"><p class="truncate text-sm font-semibold">' + escape(c.name) + '</p><span class="shrink-0 text-[11px] text-muted-foreground">' + c.time + '</span></div>' +
        '<div class="mt-0.5 flex items-center justify-between gap-2"><p class="truncate text-xs ' + (c.unread ? 'font-medium text-foreground' : 'text-muted-foreground') + '">' + (last.me ? 'شما: ' : '') + escape(last.text) + '</p>' +
        (c.unread ? '<span class="grid size-5 shrink-0 place-items-center rounded-full bg-accent text-[10px] font-bold text-white">' + Nava.utils.fa(c.unread) + '</span>' : '') + '</div></div>' +
      '</button></li>';
    }).join('') || '<li class="p-6 text-center text-sm text-muted-foreground">گفتگویی یافت نشد.</li>';
  }

  /* ---------- رشته‌ی پیام ---------- */
  const bubble = (m) =>
    '<div class="flex ' + (m.me ? 'justify-start' : 'justify-end') + '"><div class="bubble ' + (m.me ? 'bubble-me' : 'bubble-them') + '">' +
      escape(m.text) + '<span class="ms-2 inline-flex items-center gap-0.5 align-bottom text-[10px] opacity-60">' + m.time + (m.me ? icon('check', 'size-3') : '') + '</span>' +
    '</div></div>';

  function renderThread() {
    $('[data-thread-head]').innerHTML =
      '<button type="button" class="btn-icon size-9 md:hidden" data-back aria-label="بازگشت">' + icon('arrow-right', 'size-5') + '</button>' +
      avatar(active, 'size-10 text-sm') +
      '<div class="min-w-0 flex-1"><p class="truncate font-semibold">' + escape(active.name) + '</p><p class="text-xs ' + (active.online ? 'text-accent' : 'text-muted-foreground') + '" data-status>' + (active.online ? 'آنلاین' : 'آخرین بازدید اخیراً') + '</p></div>' +
      '<button type="button" class="btn-icon size-9" data-call="صوتی" aria-label="تماس صوتی">' + icon('phone', 'size-4') + '</button>' +
      '<button type="button" class="btn-icon size-9" data-call="تصویری" aria-label="تماس تصویری">' + icon('video', 'size-4') + '</button>' +
      '<a href="customers.html" class="btn-icon size-9" aria-label="پروفایل مشتری">' + icon('user', 'size-4') + '</a>';
    const thread = $('[data-thread]');
    thread.innerHTML = '<p class="mx-auto w-fit rounded-full bg-muted px-3 py-1 text-[11px] text-muted-foreground">امروز</p>' + active.messages.map(bubble).join('');
    thread.scrollTop = thread.scrollHeight;
  }

  function select(c) {
    active = c;
    c.unread = 0;
    root.dataset.view = 'thread';
    renderList();
    renderThread();
  }

  /* ---------- ارسال پیام ---------- */
  const now = () => new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit' }).format(new Date());
  function push(conv, m) {
    conv.messages.push(m);
    conv.time = m.time;
    if (conv === active) {
      const thread = $('[data-thread]');
      thread.insertAdjacentHTML('beforeend', bubble(m));
      thread.scrollTo({ top: thread.scrollHeight, behavior: 'smooth' });
    }
    renderList();
  }

  const input = $('[data-message]');
  const autosize = () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 128) + 'px'; };
  input.addEventListener('input', autosize);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('[data-composer]').requestSubmit(); }
  });

  $('[data-composer]').addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    const conv = active;
    push(conv, { me: true, text, time: now() });
    input.value = '';
    autosize();

    // پاسخ شبیه‌سازی‌شده با نشانگر «در حال نوشتن»
    setTimeout(() => {
      if (conv !== active) return;
      const status = $('[data-status]');
      status.textContent = 'در حال نوشتن…';
      const thread = $('[data-thread]');
      thread.insertAdjacentHTML('beforeend', '<div class="flex justify-end" data-typing><div class="bubble bubble-them typing flex gap-1 py-4"><span></span><span></span><span></span></div></div>');
      thread.scrollTo({ top: thread.scrollHeight, behavior: 'smooth' });
      setTimeout(() => {
        const t = $('[data-typing]');
        t && t.remove();
        if ($('[data-status]')) $('[data-status]').textContent = 'آنلاین';
        push(conv, { me: false, text: REPLIES[Math.floor(Math.random() * REPLIES.length)], time: now() });
      }, 1600);
    }, 700);
  });

  /* ---------- شکلک‌ها ---------- */
  const emoji = $('[data-emoji]');
  emoji.innerHTML = EMOJIS.map((e) => '<button type="button" class="grid size-9 place-items-center rounded-lg text-lg transition-transform hover:scale-125 hover:bg-muted">' + e + '</button>').join('');
  $('[data-emoji-toggle]').addEventListener('click', (e) => { e.stopPropagation(); emoji.dataset.open = String(emoji.dataset.open !== 'true'); });
  emoji.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    input.value += b.textContent;
    input.focus();
    emoji.dataset.open = 'false';
  });
  document.addEventListener('click', (e) => { if (!emoji.contains(e.target)) emoji.dataset.open = 'false'; });

  /* ---------- رویدادها ---------- */
  root.addEventListener('click', (e) => {
    const c = e.target.closest('[data-conv]');
    if (c) select(convs.find((x) => x.id === +c.dataset.conv));
    if (e.target.closest('[data-back]')) root.dataset.view = 'list';
    const call = e.target.closest('[data-call]');
    if (call) Nava.toast('تماس ' + call.dataset.call + ' با ' + active.name + ' در نسخه‌ی نمایشی در دسترس نیست', { type: 'info' });
  });
  $('[data-attach]').addEventListener('click', () => Nava.toast('پیوست فایل در نسخه‌ی نمایشی غیرفعال است', { type: 'info' }));
  $('[data-new-chat]').addEventListener('click', () => { location.href = 'customers.html'; });
  $('[data-chat-search]').addEventListener('input', (e) => { query = e.target.value.trim(); renderList(); });

  renderList();
  renderThread();
  Nava.effects.reveal();
})(window.Nava);
