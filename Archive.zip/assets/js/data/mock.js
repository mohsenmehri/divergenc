/**
 * داده‌های نمونه‌ی مشترک بین صفحات
 * در نسخه‌ی واقعی این لایه با فراخوانی API جایگزین می‌شود.
 */
(function (Nava) {
  'use strict';
  const { faDigits } = Nava.utils;

  /* مولد عدد تصادفی قطعی (تا داده‌ها در هر بار بارگذاری یکسان باشند) */
  let seed = 7;
  const rand = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
  const pick = (arr) => arr[Math.floor(rand() * arr.length)];
  const between = (min, max) => Math.round(min + rand() * (max - min));

  const tone = {
    primary: 'bg-primary/10 text-primary',
    info: 'bg-info/10 text-info',
    accent: 'bg-accent/10 text-accent',
    warning: 'bg-warning/15 text-warning',
    danger: 'bg-danger/10 text-danger',
  };

  const PEOPLE = [
    ['سارا محمدی', 'sara.mohammadi'], ['علی رضایی', 'ali.rezaei'], ['مریم کریمی', 'maryam.karimi'], ['رضا احمدی', 'reza.ahmadi'],
    ['نگار حسینی', 'negar.hosseini'], ['امیر نوری', 'amir.nouri'], ['زهرا موسوی', 'zahra.mousavi'], ['حسین جعفری', 'hossein.jafari'],
    ['فاطمه صادقی', 'fatemeh.sadeghi'], ['محمد کاظمی', 'mohammad.kazemi'], ['لیلا رحیمی', 'leila.rahimi'], ['کیان شریفی', 'kian.sharifi'],
    ['پریا اکبری', 'parya.akbari'], ['آرش قاسمی', 'arash.ghasemi'], ['نازنین مرادی', 'nazanin.moradi'], ['بهراد عباسی', 'behrad.abbasi'],
    ['سمانه یزدانی', 'samaneh.yazdani'], ['میلاد حیدری', 'milad.heydari'], ['الهام نجفی', 'elham.najafi'], ['پویا سلطانی', 'pouya.soltani'],
  ];
  const CITIES = ['تهران', 'اصفهان', 'شیراز', 'مشهد', 'تبریز', 'کرج', 'اهواز', 'رشت', 'قم', 'کرمان'];
  const MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر'];

  const products = [
    { name: 'هدفون بی‌سیم پرو', category: 'صوتی', price: 4850000, stock: 124, icon: 'headphones', color: 'primary', rating: 4.8 },
    { name: 'ساعت هوشمند سری ۹', category: 'پوشیدنی', price: 12900000, stock: 46, icon: 'watch', color: 'accent', rating: 4.6 },
    { name: 'گوشی هوشمند X', category: 'موبایل', price: 38500000, stock: 18, icon: 'smartphone', color: 'info', rating: 4.7 },
    { name: 'کیبورد مکانیکی', category: 'کامپیوتر', price: 3200000, stock: 7, icon: 'keyboard', color: 'warning', rating: 4.5 },
    { name: 'دوربین بدون آینه', category: 'دوربین', price: 54200000, stock: 0, icon: 'camera', color: 'danger', rating: 4.9 },
    { name: 'اسپیکر قابل حمل', category: 'صوتی', price: 2650000, stock: 210, icon: 'speaker', color: 'primary', rating: 4.3 },
    { name: 'تبلت ۱۱ اینچ', category: 'موبایل', price: 21400000, stock: 33, icon: 'tablet', color: 'accent', rating: 4.4 },
    { name: 'مانیتور ۲۷ اینچ', category: 'کامپیوتر', price: 15800000, stock: 21, icon: 'monitor', color: 'info', rating: 4.6 },
    { name: 'ماوس بی‌سیم', category: 'لوازم جانبی', price: 980000, stock: 340, icon: 'mouse', color: 'warning', rating: 4.2 },
    { name: 'پاوربانک ۲۰۰۰۰', category: 'لوازم جانبی', price: 1450000, stock: 0, icon: 'battery', color: 'danger', rating: 4.1 },
    { name: 'هدست گیمینگ', category: 'صوتی', price: 5600000, stock: 58, icon: 'headphones', color: 'primary', rating: 4.5 },
    { name: 'دستبند سلامت', category: 'پوشیدنی', price: 1890000, stock: 96, icon: 'watch', color: 'accent', rating: 4.0 },
  ].map((p, i) => Object.assign({ id: i + 1, sku: 'NV-' + (1040 + i * 7), sold: between(40, 900), status: p.stock === 0 ? 'out' : i === 11 ? 'draft' : 'active' }, p));

  const customers = PEOPLE.map(([name, slug], i) => {
    const orders = between(1, 42);
    return {
      id: i + 1,
      name,
      email: slug + '@gmail.com',
      phone: faDigits('0912' + between(1000000, 9999999)),
      city: CITIES[i % CITIES.length],
      orders,
      spent: orders * between(900000, 6000000),
      joined: faDigits(between(1, 28)) + ' ' + pick(MONTHS) + ' ' + faDigits(1400 + between(1, 5)),
      status: orders > 30 ? 'vip' : i % 6 === 5 ? 'inactive' : 'active',
    };
  });

  const STATUS_FLOW = ['paid', 'shipping', 'paid', 'pending', 'delivered', 'shipping', 'paid', 'canceled', 'delivered', 'delivered'];
  const PAY = ['کارت بانکی', 'کیف پول', 'پرداخت در محل'];
  const orders = Array.from({ length: 36 }, (_, i) => {
    const c = customers[(i * 7) % customers.length];
    const p = products[(i * 5) % products.length];
    const qty = 1 + (i % 3 === 0 ? 1 : 0);
    const day = 22 - Math.floor(i / 3);
    return {
      id: '#' + faDigits(8421 - i),
      customer: c.name,
      email: c.email,
      city: c.city,
      product: p.name,
      productIcon: p.icon,
      qty,
      amount: p.price * qty,
      status: STATUS_FLOW[i % STATUS_FLOW.length],
      payment: PAY[i % PAY.length],
      date: faDigits(day > 0 ? day : day + 30) + ' ' + (day > 0 ? 'مهر' : 'شهریور') + ' ۱۴۰۵',
    };
  });

  const status = {
    paid: { label: 'پرداخت‌شده', cls: 'badge-primary' },
    shipping: { label: 'در حال ارسال', cls: 'badge-info' },
    delivered: { label: 'تحویل‌شده', cls: 'badge-muted' },
    pending: { label: 'در انتظار', cls: 'badge-warning' },
    canceled: { label: 'لغو شده', cls: 'badge-danger' },
  };

  const productStatus = {
    active: { label: 'فعال', cls: 'badge-primary' },
    draft: { label: 'پیش‌نویس', cls: 'badge-muted' },
    out: { label: 'ناموجود', cls: 'badge-danger' },
  };

  const customerStatus = {
    vip: { label: 'ویژه', cls: 'badge-accent' },
    active: { label: 'فعال', cls: 'badge-primary' },
    inactive: { label: 'غیرفعال', cls: 'badge-muted' },
  };

  const notifications = [
    { icon: 'bag', color: 'accent', text: '<b>۱۲ سفارش جدید</b> در انتظار تأیید است', time: 'همین الان', unread: true, href: 'orders.html' },
    { icon: 'package', color: 'warning', text: 'موجودی <b>کیبورد مکانیکی</b> رو به اتمام است', time: '۲۰ دقیقه پیش', unread: true, href: 'products.html' },
    { icon: 'message', color: 'info', text: '<b>علی رضایی</b> یک پیام جدید فرستاد', time: '۱ ساعت پیش', unread: false, href: 'messages.html' },
    { icon: 'card', color: 'primary', text: 'تسویه‌ی هفتگی با موفقیت انجام شد', time: 'دیروز', unread: false, href: 'reports.html' },
  ];

  const conversations = [
    {
      id: 1, name: 'علی رضایی', online: true, unread: 2, time: '۱۰:۴۲',
      messages: [
        { me: false, text: 'سلام، وقت بخیر. سفارش #۸۴۲۰ من کی ارسال می‌شه؟', time: '۱۰:۳۰' },
        { me: true, text: 'سلام علی جان، وقت شما هم بخیر 🌹 سفارشتون امروز تحویل پست شد.', time: '۱۰:۳۵' },
        { me: true, text: 'کد رهگیری: ۲۳۸۴۰۹۱۲۷۷', time: '۱۰:۳۵' },
        { me: false, text: 'عالیه، ممنون از پیگیری سریعتون!', time: '۱۰:۴۱' },
        { me: false, text: 'فقط امکانش هست فاکتور رسمی هم صادر بشه؟', time: '۱۰:۴۲' },
      ],
    },
    {
      id: 2, name: 'سارا محمدی', online: true, unread: 0, time: '۰۹:۱۵',
      messages: [
        { me: false, text: 'هدفون رو گرفتم، کیفیتش فوق‌العاده‌ست 😍', time: '۰۹:۱۲' },
        { me: true, text: 'خوشحالیم که راضی بودید! منتظر نظرتون در سایت هستیم.', time: '۰۹:۱۵' },
      ],
    },
    {
      id: 3, name: 'مریم کریمی', online: false, unread: 1, time: 'دیروز',
      messages: [{ me: false, text: 'کیبورد مکانیکی دوباره موجود می‌شه؟', time: 'دیروز' }],
    },
    {
      id: 4, name: 'رضا احمدی', online: false, unread: 0, time: 'دیروز',
      messages: [
        { me: false, text: 'برای خرید عمده تخفیف دارید؟', time: 'دیروز' },
        { me: true, text: 'بله، برای خرید بالای ۱۰ عدد ۱۵٪ تخفیف داریم.', time: 'دیروز' },
      ],
    },
    {
      id: 5, name: 'نگار حسینی', online: true, unread: 0, time: 'شنبه',
      messages: [{ me: false, text: 'لغو سفارش انجام شد، ممنون.', time: 'شنبه' }],
    },
    {
      id: 6, name: 'تیم پشتیبانی', online: true, unread: 0, time: 'جمعه',
      messages: [{ me: false, text: 'گزارش هفتگی تیکت‌ها آماده است.', time: 'جمعه' }],
    },
  ];

  Nava.data = { tone, products, customers, orders, status, productStatus, customerStatus, notifications, conversations, CITIES };
})(window.Nava);
